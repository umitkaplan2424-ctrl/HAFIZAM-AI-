import React, { useState, useEffect, useRef } from 'react';
import { Mic, Power, Check, AlertCircle, RefreshCw, Send, Sparkles, Volume2 } from 'lucide-react';
import { processAIQuery, speakText, stopSpeaking } from '../lib/aiService';
import { MemoryItem, ReminderItem, ProcessAIResponse } from '../types';
import { formatReminderDisplay } from '../lib/notificationService';

interface HandsFreeWakeWordProps {
  memories: MemoryItem[];
  reminders: ReminderItem[];
  onAddMemory: (item: Omit<MemoryItem, 'id' | 'createdAt'>) => MemoryItem;
  onAddReminder: (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => ReminderItem;
  onMicStateChange?: (active: boolean) => void;
  onTranscriptChange?: (text: string) => void;
}

type StatusPhase =
  | 'off'
  | 'listening'    // 🎙️ "Seni dinliyorum..."
  | 'processing'   // 🧠 "Düşünüyorum..."
  | 'done'         // ✓ "Tamamlandı"
  | 'error';        // "Hata oluştu"

export const HandsFreeWakeWord: React.FC<HandsFreeWakeWordProps> = ({
  memories,
  reminders,
  onAddMemory,
  onAddReminder,
  onMicStateChange,
  onTranscriptChange,
}) => {
  const [isEnabled, setIsEnabled] = useState<boolean>(false);
  const [phase, setPhase] = useState<StatusPhase>('off');
  const [transcript, setTranscript] = useState<string>('');
  const [createdReminderInfo, setCreatedReminderInfo] = useState<{ title: string; timeStr: string } | null>(null);
  const [aiResponse, setAiResponse] = useState<ProcessAIResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const silenceTimerRef = useRef<any>(null);
  const timeoutRef = useRef<any>(null);
  const isEnabledRef = useRef<boolean>(false);
  const isProcessingRef = useRef<boolean>(false);

  // Keep isEnabledRef synced with isEnabled state
  useEffect(() => {
    isEnabledRef.current = isEnabled;
    if (onMicStateChange) {
      onMicStateChange(isEnabled);
    }
  }, [isEnabled, onMicStateChange]);

  // Stop all recognition cleanly
  const stopListeningCleanly = () => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    if (mediaStreamRef.current) {
      try {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      } catch (e) {}
      mediaStreamRef.current = null;
    }

    if (recognitionRef.current) {
      try {
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.onspeechend = null;
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }
  };

  // Execute AI Analysis & Create Reminder
  const handleExecuteCommand = async (commandStr: string) => {
    if (isProcessingRef.current) return;

    const textToProcess = commandStr.trim();
    if (!textToProcess) {
      setPhase('error');
      setErrorMessage('Konuşma metne dönüştürülemedi.');
      return;
    }

    isProcessingRef.current = true;
    setPhase('processing');
    setErrorMessage(null);
    setCreatedReminderInfo(null);

    try {
      const response = await processAIQuery({
        prompt: textToProcess,
        currentMemories: memories,
        currentReminders: reminders,
      });

      setAiResponse(response);

      const isRemind =
        response.intent === 'remind' ||
        textToProcess.toLowerCase().includes('hatırlat') ||
        textToProcess.toLowerCase().includes('uyandır') ||
        textToProcess.toLowerCase().includes('alarm');

      const reminderData =
        response.reminderToSave ||
        (isRemind
          ? {
              title:
                textToProcess
                  .replace(/(bana|hatırlat|uyandır|alarm|kur|bugün|yarın|saat|\d{1,2}[:.]\d{2}|lütfen)/gi, '')
                  .trim() || 'Hatırlatma',
              dateTime: new Date(Date.now() + 3600000).toISOString(),
              repeatFrequency: 'none' as const,
            }
          : null);

      if (reminderData) {
        const created = onAddReminder({
          title: reminderData.title || 'Hatırlatma',
          dateTime: reminderData.dateTime || new Date(Date.now() + 3600000).toISOString(),
          repeatFrequency: reminderData.repeatFrequency || 'none',
        });

        const fmtDisplay = formatReminderDisplay(created.dateTime);
        setCreatedReminderInfo({
          title: created.title,
          timeStr: fmtDisplay.fullText,
        });

        setPhase('done');
        speakText(`Hatırlatıcı oluşturuldu. ${created.title}, ${fmtDisplay.fullText}`);
      } else if (response.memoryToSave) {
        onAddMemory({
          title: response.memoryToSave.title,
          content: response.memoryToSave.content,
          category: response.memoryToSave.category || 'Not',
          tags: response.memoryToSave.tags || ['sesli'],
          source: 'voice',
        });
        setPhase('done');
        speakText(response.speechText || response.responseText);
      } else {
        setPhase('done');
        speakText(response.speechText || response.responseText);
      }
    } catch (err) {
      console.error('AI Query Error:', err);
      setPhase('error');
      setErrorMessage('Komutunu anlayamadım.');
      speakText('Komutunu anlayamadım.');
    } finally {
      isProcessingRef.current = false;
    }
  };

  // Start Voice Listening Session
  const startListeningSession = async () => {
    stopListeningCleanly();
    setErrorMessage(null);
    setTranscript('');
    setCreatedReminderInfo(null);
    setAiResponse(null);

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMessage('Sesli giriş kullanılamıyor. Tarayıcınız Web Speech API desteklemiyor.');
      setIsEnabled(false);
      setPhase('error');
      return;
    }

    // 1. Android/Browser compatibility: Request audio stream via getUserMedia first, then immediately stop tracks so mic hardware is released for SpeechRecognition
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (err: any) {
        console.warn('getUserMedia mic request warning:', err);
        if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
          setErrorMessage('Sesli giriş kullanılamıyor. Mikrofon izni reddedildi.');
          setIsEnabled(false);
          setPhase('error');
          return;
        }
      }
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'tr-TR';
    recognition.maxAlternatives = 1;

    setPhase('listening');
    let collectedText = '';

    // Safety timeout: 15s if no speech detected at all
    timeoutRef.current = setTimeout(() => {
      if (!collectedText.trim()) {
        if (isEnabledRef.current) {
          setPhase('listening');
        } else {
          stopListeningCleanly();
          setPhase('off');
        }
      }
    }, 15000);

    recognition.onstart = () => {
      setPhase('listening');
    };

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = 0; i < event.results.length; i++) {
        currentTranscript += event.results[i][0].transcript;
      }

      const cleanText = currentTranscript.trim();
      if (cleanText) {
        collectedText = cleanText;
        setTranscript(cleanText);

        if (onTranscriptChange) {
          onTranscriptChange(cleanText);
        }

        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        // 2.8s silence window to prevent premature stop during natural speech pauses
        silenceTimerRef.current = setTimeout(() => {
          try {
            recognition.stop();
          } catch (e) {}
        }, 2800);
      }
    };

    recognition.onspeechend = () => {
      try {
        recognition.stop();
      } catch (e) {}
    };

    recognition.onerror = (event: any) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      console.warn('Speech recognition error:', event.error);

      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        stopListeningCleanly();
        setErrorMessage('Sesli giriş kullanılamıyor. Mikrofon izni engellendi.');
        setIsEnabled(false);
        setPhase('error');
        return;
      }

      // Non-fatal errors like 'no-speech' or 'aborted' are ignored if no text collected
      if (event.error === 'no-speech' || event.error === 'aborted') {
        return;
      }

      if (!collectedText.trim() && !isEnabledRef.current) {
        stopListeningCleanly();
        setPhase('error');
        setErrorMessage('Konuşma metne dönüştürülemedi.');
      }
    };

    recognition.onend = () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);

      const finalText = collectedText.trim();
      if (finalText) {
        setTranscript(finalText);
        if (onTranscriptChange) {
          onTranscriptChange(finalText);
        }
        handleExecuteCommand(finalText);
      } else if (isEnabledRef.current) {
        // Hands-free remains active and ready for speech
        setPhase('listening');
      } else {
        setPhase('off');
      }
    };

    recognitionRef.current = recognition;

    try {
      recognition.start();
    } catch (e) {
      console.error('Recognition start error:', e);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (isEnabledRef.current) {
        setPhase('listening');
      } else {
        setPhase('error');
        setErrorMessage('Konuşma metne dönüştürülemedi.');
      }
    }
  };

  // Toggle Hands-Free
  const handleToggle = () => {
    if (!isEnabled) {
      stopSpeaking();
      setIsEnabled(true);
      startListeningSession();
    } else {
      setIsEnabled(false);
      stopSpeaking();
      stopListeningCleanly();
      setPhase('off');
      setTranscript('');
    }
  };

  // Initial load: Microphone strictly OFF
  useEffect(() => {
    stopListeningCleanly();
    setPhase('off');
  }, []);

  // Cleanup on unmount or disable
  useEffect(() => {
    if (!isEnabled) {
      stopListeningCleanly();
      setPhase('off');
    }
    return () => {
      stopListeningCleanly();
      stopSpeaking();
    };
  }, [isEnabled]);

  return (
    <div className="bg-white dark:bg-slate-800/95 border border-slate-200 dark:border-slate-700/80 rounded-3xl p-4 shadow-md space-y-3 transition-all">
      {/* Toggle Button */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={handleToggle}
          className={`w-full px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-extrabold transition-all flex items-center justify-center gap-2 border cursor-pointer shadow-xs ${
            isEnabled
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white border-emerald-600'
              : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-600'
          }`}
        >
          <Power className="w-4 h-4" />
          <span>{isEnabled ? 'Eller Serbest: AÇIK' : 'Eller Serbest: KAPALI'}</span>
        </button>
      </div>

      {/* ACTIVE HANDS-FREE CARD */}
      {isEnabled && (
        <div className="p-4 bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3">
          {/* Status Header */}
          <div className="flex items-center justify-between text-xs font-bold">
            {phase === 'listening' && (
              <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-2 font-extrabold animate-pulse">
                <Mic className="w-4 h-4 text-emerald-500 animate-bounce" />
                🎙️ Seni dinliyorum...
              </span>
            )}

            {phase === 'processing' && (
              <span className="text-purple-600 dark:text-purple-400 flex items-center gap-2 font-extrabold">
                <RefreshCw className="w-4 h-4 animate-spin text-purple-500" />
                🧠 Komut anlaşılıyor...
              </span>
            )}

            {phase === 'done' && (
              <span className="text-emerald-700 dark:text-emerald-300 flex items-center gap-2 font-extrabold">
                <Check className="w-4 h-4 text-emerald-500" />
                ✓ İşlem tamamlandı
              </span>
            )}

            {phase === 'error' && (
              <span className="text-red-600 dark:text-red-400 flex items-center gap-2 font-bold">
                <AlertCircle className="w-4 h-4 text-red-500" />
                Hata
              </span>
            )}

            <button
              type="button"
              onClick={() => startListeningSession()}
              className="px-2.5 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-[11px] font-bold rounded-xl flex items-center gap-1 cursor-pointer"
            >
              <Mic className="w-3 h-3 text-indigo-500" /> Tekrar Dinle
            </button>
          </div>

          {/* AUDIO ANIMATED WAVE VISUALIZER */}
          {phase === 'listening' && (
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 px-3 py-2 rounded-xl">
              <Volume2 className="w-3.5 h-3.5 text-emerald-500 animate-pulse shrink-0" />
              <div className="flex-1 flex items-center gap-1 h-3">
                <span className="w-1.5 h-full bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1.5 h-full bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1.5 h-full bg-emerald-500 rounded-full animate-bounce" />
                <span className="w-1.5 h-full bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1.5 h-full bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
              </div>
              <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400">
                Mikrofon Aktif
              </span>
            </div>
          )}

          {/* REALTIME SPEECH TRANSCRIPT DISPLAY BOX */}
          <div className="p-3 bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 rounded-2xl space-y-1.5 shadow-xs">
            <span className="text-[10px] font-extrabold uppercase font-mono text-slate-400 block">
              Söylenen Cümle (Metin):
            </span>
            <p className="text-sm font-semibold text-slate-900 dark:text-white min-h-[3rem] p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700/60 leading-snug">
              {transcript || (
                <span className="text-slate-400 italic font-normal">
                  “Yarın saat 09:00'da bana su içmeyi hatırlat.” gibi bir cümle söyleyin...
                </span>
              )}
            </p>
          </div>

          {/* CREATED REMINDER SUCCESS DISPLAY */}
          {createdReminderInfo && (
            <div className="p-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-2xl shadow-md space-y-1 animate-fade-in">
              <div className="flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider text-emerald-200">
                <Check className="w-4 h-4 text-white" /> Hatırlatıcı oluşturuldu.
              </div>
              <div className="text-sm font-extrabold">
                🔔 {createdReminderInfo.title} — {createdReminderInfo.timeStr}
              </div>
            </div>
          )}

          {/* ERROR DISPLAY */}
          {errorMessage && (
            <div className="p-3 bg-red-100 dark:bg-red-950/80 text-red-800 dark:text-red-200 text-xs font-bold rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* AI EXPLANATION IF ANSWER OR REMINDER */}
          {aiResponse && !createdReminderInfo && (
            <div className="p-3 bg-indigo-50 dark:bg-indigo-950/70 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs text-indigo-950 dark:text-indigo-200 space-y-1">
              <p className="text-sm font-medium">{aiResponse.responseText}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
