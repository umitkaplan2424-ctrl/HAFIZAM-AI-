import React from 'react';
import { ShieldCheck, Mic, MicOff } from 'lucide-react';

interface PrivacyBadgeProps {
  activeMic?: boolean;
}

export const PrivacyBadge: React.FC<PrivacyBadgeProps> = ({ activeMic = false }) => {
  return (
    <div className="bg-emerald-500/10 dark:bg-emerald-500/15 border border-emerald-500/30 rounded-2xl p-3 text-xs text-emerald-800 dark:text-emerald-300 backdrop-blur-sm transition-all shadow-xs space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <span className="font-medium tracking-tight">
            Gizlilik Koruması: <span className="font-semibold text-emerald-900 dark:text-emerald-200">Sadece sen çağırınca çalışır</span>
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1 border-t border-emerald-500/20 text-[11px] font-semibold">
        {activeMic ? (
          <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 font-bold">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <Mic className="w-3.5 h-3.5 text-emerald-500" />
            <span>Dinleme: Aktif</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <span className="w-2 h-2 rounded-full bg-slate-400" />
            <MicOff className="w-3.5 h-3.5 text-slate-400" />
            <span>Dinleme: Kapalı</span>
          </div>
        )}
      </div>
    </div>
  );
};
