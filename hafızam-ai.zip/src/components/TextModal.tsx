import React, { useState } from 'react';
import { processAIQuery } from '../lib/aiService';
import { MemoryItem, ReminderItem, ProcessAIResponse } from '../types';
import { Keyboard, ArrowLeft, Send, Brain, Sparkles, Check, RefreshCw, PlusCircle } from 'lucide-react';
import { formatReminderDisplay } from '../lib/notificationService';

interface TextModalProps {
  onBack: () => void;
  memories: MemoryItem[];
  reminders: ReminderItem[];
  onAddMemory: (item: Omit<MemoryItem, 'id' | 'createdAt'>) => MemoryItem;
  onAddReminder: (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => ReminderItem;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  responseObj?: ProcessAIResponse;
  savedBadge?: string;
  timestamp: string;
}

export const TextModal: React.FC<TextModalProps> = ({
  onBack,
  memories,
  reminders,
  onAddMemory,
  onAddReminder,
}) => {
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: 'Merhaba! Ben HAFIZAM AI. Ne kaydetmek, hatırlatmak veya öğrenmek istersin?',
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || loading) return;

    const userMsgId = 'msg-' + Date.now();
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    const result = await processAIQuery({
      prompt: text,
      currentMemories: memories,
      currentReminders: reminders,
    });

    let badge: string | undefined;

    if (result.memoryToSave) {
      onAddMemory({
        title: result.memoryToSave.title,
        content: result.memoryToSave.content,
        category: result.memoryToSave.category || 'Not',
        tags: result.memoryToSave.tags || ['yazılı-not'],
        source: 'text',
      });
      badge = '🧠 Hafızaya kaydedildi';
    }

    if (result.reminderToSave) {
      const created = onAddReminder({
        title: result.reminderToSave.title,
        dateTime: result.reminderToSave.dateTime || new Date(Date.now() + 3600000).toISOString(),
        repeatFrequency: result.reminderToSave.repeatFrequency || 'none',
      });
      const displayTime = formatReminderDisplay(created.dateTime).timeOnly;
      badge = `🔔 Hatırlatma oluşturuldu — ${displayTime}`;
    }

    const aiMsg: ChatMessage = {
      id: 'ai-' + Date.now(),
      sender: 'ai',
      text: result.responseText,
      responseObj: result,
      savedBadge: badge,
      timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, aiMsg]);
    setLoading(false);
  };

  const PRESET_CHIPS = [
    'Bu wifi şifresini hatırla: Hafizam2026',
    'Bana yarın 10:00\'da faturayı hatırlat',
    'Geçen ay kaydettiğim garanti belgesini bul',
    'Araba muayene tarihim neydi?',
  ];

  return (
    <div className="flex flex-col h-[75vh] max-h-[700px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-xl overflow-hidden animate-fade-in">
      {/* Header */}
      <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700/80 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600"
        >
          <ArrowLeft className="w-4 h-4" /> Geri
        </button>
        <div className="flex items-center gap-2">
          <Keyboard className="w-4 h-4 text-indigo-500" />
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Yazılı Komut Modu</span>
        </div>
      </div>

      {/* Preset Chips */}
      <div className="px-4 py-2 bg-slate-100/60 dark:bg-slate-950/40 border-b border-slate-200/50 dark:border-slate-800/50 overflow-x-auto flex gap-1.5 scrollbar-none">
        {PRESET_CHIPS.map((chip, i) => (
          <button
            key={i}
            onClick={() => handleSend(chip)}
            className="whitespace-nowrap px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-950 hover:text-indigo-600 transition-colors shadow-2xs"
          >
            💬 {chip}
          </button>
        ))}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'} space-y-1`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-2xs ${
                m.sender === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-none'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-200/60 dark:border-slate-700/60'
              }`}
            >
              {m.savedBadge && (
                <div className="mb-2 px-2.5 py-1 bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 rounded-lg text-[11px] font-bold flex items-center gap-1.5 border border-emerald-500/30">
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  {m.savedBadge}
                </div>
              )}
              <p className="whitespace-pre-wrap">{m.text}</p>
            </div>
            <span className="text-[10px] text-slate-400 px-1">{m.timestamp}</span>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl w-fit text-xs text-slate-500 animate-pulse">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-500" />
            HAFIZAM AI düşünüyor...
          </div>
        )}
      </div>

      {/* Text Input Footer */}
      <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Komut yaz (ör. 'Bu faturayı hatırla: Elektrik 450 TL')..."
          className="flex-1 px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
        />
        <button
          onClick={() => handleSend()}
          disabled={!inputText.trim() || loading}
          className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-2xl font-bold transition-all shadow-md shadow-indigo-500/20"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
