import React, { useState } from 'react';
import { MemoryItem, CategoryType } from '../types';
import { Brain, Search, Filter, Plus, Trash2, Edit3, ArrowLeft, Tag, Calendar, AlertTriangle, X, Check, FileText, Sparkles } from 'lucide-react';

interface MemoryScreenProps {
  onBack: () => void;
  memories: MemoryItem[];
  onAddMemory: (item: Omit<MemoryItem, 'id' | 'createdAt'>) => MemoryItem;
  onUpdateMemory: (item: MemoryItem) => void;
  onDeleteMemory: (id: string) => void;
  onClearAllMemories: () => void;
  initialSearchQuery?: string;
}

export const MemoryScreen: React.FC<MemoryScreenProps> = ({
  onBack,
  memories,
  onAddMemory,
  onUpdateMemory,
  onDeleteMemory,
  onClearAllMemories,
  initialSearchQuery = '',
}) => {
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'Tümü'>('Tümü');
  const [activeMemoryDetail, setActiveMemoryDetail] = useState<MemoryItem | null>(null);

  // Modals state
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Form states for add/edit
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formCategory, setFormCategory] = useState<CategoryType>('Not');
  const [formTags, setFormTags] = useState('');

  const CATEGORIES: (CategoryType | 'Tümü')[] = ['Tümü', 'Belge', 'Ürün', 'Cihaz', 'Fatura', 'Not', 'Diğer'];

  // Filter logic
  const filteredMemories = memories.filter((m) => {
    const matchesCat = selectedCategory === 'Tümü' || m.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      !query ||
      m.title.toLowerCase().includes(query) ||
      m.content.toLowerCase().includes(query) ||
      m.tags.some((t) => t.toLowerCase().includes(query));
    return matchesCat && matchesSearch;
  });

  const handleOpenAdd = () => {
    setFormTitle('');
    setFormContent('');
    setFormCategory('Not');
    setFormTags('');
    setIsAddingNew(true);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) return;

    onAddMemory({
      title: formTitle.trim(),
      content: formContent.trim(),
      category: formCategory,
      tags: formTags ? formTags.split(',').map((t) => t.trim()) : ['manuel'],
      source: 'manual',
    });

    setIsAddingNew(false);
  };

  const handleOpenEdit = (m: MemoryItem) => {
    setActiveMemoryDetail(m);
    setFormTitle(m.title);
    setFormContent(m.content);
    setFormCategory(m.category);
    setFormTags(m.tags.join(', '));
    setIsEditing(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMemoryDetail || !formTitle.trim()) return;

    onUpdateMemory({
      ...activeMemoryDetail,
      title: formTitle.trim(),
      content: formContent.trim(),
      category: formCategory,
      tags: formTags ? formTags.split(',').map((t) => t.trim()) : activeMemoryDetail.tags,
    });

    setIsEditing(false);
    setActiveMemoryDetail(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600"
        >
          <ArrowLeft className="w-4 h-4" /> Geri
        </button>
        <button
          onClick={handleOpenAdd}
          className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-teal-600/20"
        >
          <Plus className="w-4 h-4" /> Yeni Kayıt
        </button>
      </div>

      {/* Screen Title & Header */}
      <div className="bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-3xl p-6 shadow-lg space-y-2">
        <div className="flex items-center gap-2">
          <Brain className="w-8 h-8 text-teal-100" />
          <h2 className="text-2xl font-black">Hafıza Bankam</h2>
        </div>
        <p className="text-xs text-teal-100 max-w-md">
          Özel olarak kaydetmesini istediğin tüm bilgiler burada saklanır. Asistan senin hakkında sadece buradaki gerçek bilgileri bilir.
        </p>
      </div>

      {/* Transparency Guarantee Info Box */}
      <div className="p-3.5 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 rounded-2xl text-xs text-teal-900 dark:text-teal-200 flex items-start gap-2.5">
        <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="font-bold">🔒 %100 Şeffaf & Doğrulanmış Hafıza</p>
          <p className="text-[11px] text-teal-700 dark:text-teal-300 leading-snug">
            HAFIZAM AI, kişisel bilgilerinizi asla tahmin etmez veya uydurmaz. Asistan, yalnızca sizin açıkça söylediğiniz ve bu ekranda listelenen gerçek kayıtları hatırlar.
          </p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Hafızada ara..."
            className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Memories List */}
      {filteredMemories.length === 0 ? (
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 text-center border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
          <Brain className="w-10 h-10 text-slate-400 mx-auto opacity-50" />
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Aradığınız kriterlere uygun hafıza kaydı bulunamadı.
          </p>
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-teal-50 text-teal-600 dark:bg-teal-950/80 dark:text-teal-300 rounded-xl text-xs font-bold hover:bg-teal-100"
          >
            + İlk Kaydı Kendin Ekle
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {filteredMemories.map((m) => (
            <div
              key={m.id}
              className="bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 rounded-3xl p-4 shadow-sm hover:shadow-md hover:border-teal-400 dark:hover:border-teal-500 transition-all flex flex-col justify-between space-y-3 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-1 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                      {m.category}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                      {m.source === 'voice' ? '🎤 Sesli' : m.source === 'camera' ? '📷 Kamera' : '✍️ Kullanıcı'}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                    <Calendar className="w-3 h-3" />
                    {new Date(m.createdAt).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white line-clamp-1 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                  {m.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                  {m.content}
                </p>

                {m.imageUrl && (
                  <div className="mt-2 rounded-xl overflow-hidden max-h-28 bg-slate-900">
                    <img src={m.imageUrl} alt={m.title} className="w-full h-28 object-cover" />
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 flex-wrap">
                  {m.tags.slice(0, 2).map((t, idx) => (
                    <span key={idx} className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-900 px-2 py-0.5 rounded-md">
                      #{t}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenEdit(m)}
                    className="p-1.5 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400"
                    title="Düzenle"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteMemory(m.id)}
                    className="p-1.5 text-slate-400 hover:text-red-500"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* DANGER ZONE: Bütün Hafızamı Sil */}
      <div className="pt-6 border-t border-slate-200 dark:border-slate-800 text-center">
        <button
          onClick={() => setShowClearConfirm(true)}
          className="px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 rounded-2xl text-xs font-bold transition-colors inline-flex items-center gap-2"
        >
          <AlertTriangle className="w-4 h-4 text-red-500" /> Bütün Hafızamı Sil
        </button>
      </div>

      {/* ADD MANUAL MEMORY MODAL */}
      {isAddingNew && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4 border border-slate-200 dark:border-slate-700 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-teal-600" /> Yeni Hafıza Kaydı
              </h3>
              <button onClick={() => setIsAddingNew(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAdd} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Başlık</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="ör. Ev Tapusu Seri Numarası"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Detay/İçerik</label>
                <textarea
                  required
                  rows={3}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Kayıtlı kalmasını istediğin bilgiyi buraya yaz..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Kategori</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    {CATEGORIES.filter((c) => c !== 'Tümü').map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Etiketler (Virgülle)</label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    placeholder="ev, önemli, şifre"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-semibold"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold"
                >
                  Hafızaya Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT MEMORY MODAL */}
      {isEditing && activeMemoryDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4 border border-slate-200 dark:border-slate-700 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-teal-600" /> Hafıza Kaydını Düzenle
              </h3>
              <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Başlık</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">İçerik</label>
                <textarea
                  required
                  rows={4}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Kategori</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  >
                    {CATEGORIES.filter((c) => c !== 'Tümü').map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Etiketler</label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center">
                <button
                  type="button"
                  onClick={() => {
                    onDeleteMemory(activeMemoryDetail.id);
                    setIsEditing(false);
                  }}
                  className="text-red-500 font-semibold hover:underline"
                >
                  Bu Kaydı Sil
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-semibold"
                  >
                    Vazgeç
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold"
                  >
                    Güncelle
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CLEAR ALL CONFIRMATION DIALOG */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-sm shadow-2xl text-center space-y-4 border border-red-500/30 animate-scale-up">
            <div className="w-12 h-12 rounded-full bg-red-500/10 text-red-500 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">Bütün Hafızayı Sil?</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Bu işlem geri alınamaz. Kaydedilmiş tüm verileriniz ve hatırlatmalarınız kalıcı olarak silinecektir.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl text-xs font-bold"
              >
                Vazgeç
              </button>
              <button
                onClick={() => {
                  onClearAllMemories();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-red-600/20"
              >
                Evet, Tümünü Sil
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
