import React, { useState } from 'react';
import { AppView, ReminderItem, MemoryItem } from '../types';
import { PrivacyBadge } from './PrivacyBadge';
import { HandsFreeWakeWord } from './HandsFreeWakeWord';
import { processAIQuery, speakText } from '../lib/aiService';
import { formatReminderDisplay } from '../lib/notificationService';
import { Send, Keyboard, Bell, CheckCircle2, Clock, Trash2, Check, AlertCircle, RefreshCw, Sparkles, Info } from 'lucide-react';

interface HomeScreenProps {
  setCurrentView: (view: AppView) => void;
  reminders: ReminderItem[];
  onToggleReminder: (id: string) => void;
  onAddReminder: (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => ReminderItem;
  onDeleteReminder: (id: string) => void;
  memories?: MemoryItem[];
  onAddMemory?: (item: Omit<MemoryItem, 'id' | 'createdAt'>) => MemoryItem;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  setCurrentView,
  reminders,
  onToggleReminder,
  onAddReminder,
  onDeleteReminder,
  memories = [],
  onAddMemory = (item: Omit<MemoryItem, 'id' | 'createdAt'>) => ({} as MemoryItem),
}) => {
  const [writtenCommand, setWrittenCommand] = useState<string>('');
  const [isProcessingWritten, setIsProcessingWritten] = useState<boolean>(false);
  const [activeMicState, setActiveMicState] = useState<boolean>(false);

  // Status feedback state
  const [createdFeedback, setCreatedFeedback] = useState<{ title: string; timeStr: string } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Handle Written Command Submit
  const handleWrittenSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const promptText = writtenCommand.trim();
    if (!promptText || isProcessingWritten) return;

    setIsProcessingWritten(true);
    setCreatedFeedback(null);
    setErrorMessage(null);

    try {
      const response = await processAIQuery({
        prompt: promptText,
        currentReminders: reminders,
        currentMemories: memories,
      });

      const reminderData = response.reminderToSave || (response.intent === 'remind' ? {
        title: promptText.replace(/(bana|hatırlat|uyandır|alarm|kur|bugün|yarın|saat|\d{1,2}[:.]\d{2}|lütfen)/gi, '').trim() || 'Hatırlatma',
        dateTime: new Date(Date.now() + 3600000).toISOString(),
        repeatFrequency: 'none' as const,
      } : null);

      if (reminderData) {
        const created = onAddReminder({
          title: reminderData.title || 'Hatırlatma',
          dateTime: reminderData.dateTime || new Date(Date.now() + 3600000).toISOString(),
          repeatFrequency: reminderData.repeatFrequency || 'none',
        });

        const fmtDisplay = formatReminderDisplay(created.dateTime);
        setCreatedFeedback({
          title: created.title,
          timeStr: fmtDisplay.fullText,
        });

        setWrittenCommand('');
        speakText(`Hatırlatıcı oluşturuldu: ${created.title}, ${fmtDisplay.fullText}`);
      } else if (response.memoryToSave && onAddMemory) {
        const createdMem = onAddMemory({
          title: response.memoryToSave.title,
          content: response.memoryToSave.content,
          category: response.memoryToSave.category || 'Not',
          tags: response.memoryToSave.tags || ['kişisel'],
          source: 'text',
        });
        setCreatedFeedback({
          title: createdMem.title,
          timeStr: 'Hafızaya kaydedildi',
        });
        setWrittenCommand('');
        speakText(`${createdMem.title} hafızaya kaydedildi.`);
      } else {
        setErrorMessage(response.responseText || 'Komut işlenemedi.');
      }
    } catch (err) {
      console.error('Error processing written command:', err);
      setErrorMessage('Komutunu anlayamadım.');
    } finally {
      setIsProcessingWritten(false);
    }
  };

  const pendingReminders = reminders.filter((r) => r.status === 'pending');

  return (
    <div className="space-y-6 pb-8 animate-fade-in">
      {/* Privacy Notice Badge with Dynamic Mic Indicator */}
      <PrivacyBadge activeMic={activeMicState} />

      {/* Main App Title & Subtitle Header */}
      <div className="text-center pt-2 pb-1 space-y-1.5">
        <h2 className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
          HAFIZAM
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-base sm:text-lg font-semibold">
          “Sen çağır, ben hatırlayayım.”
        </p>
      </div>

      {/* Center Main Command Field ("Ne yapmamı istersin?") */}
      <div className="bg-white dark:bg-slate-800/95 border border-slate-200 dark:border-slate-700 rounded-3xl p-5 shadow-lg space-y-3">
        <label className="block text-sm font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          Ne yapmamı istersin?
        </label>

        <form onSubmit={handleWrittenSubmit} className="space-y-3">
          <textarea
            rows={3}
            value={writtenCommand}
            onChange={(e) => setWrittenCommand(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleWrittenSubmit();
              }
            }}
            placeholder="Örn: 'Yarın saat 09:00'da bana su içmeyi hatırlat.'"
            className="w-full p-3.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all resize-none leading-relaxed"
          />

          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-400 font-medium">
              Yazıp veya söyleyip Gönder'e dokunun.
            </span>
            <button
              type="submit"
              disabled={!writtenCommand.trim() || isProcessingWritten}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              {isProcessingWritten ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  İşleniyor...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Gönder
                </>
              )}
            </button>
          </div>
        </form>

        {/* Success Confirmation Banner */}
        {createdFeedback && (
          <div className="p-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-2xl shadow-md space-y-1 animate-fade-in">
            <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-emerald-200">
              <Check className="w-4 h-4 text-white" /> Hatırlatıcı oluşturuldu.
            </div>
            <div className="text-sm font-bold">
              🔔 {createdFeedback.title} — {createdFeedback.timeStr}
            </div>
          </div>
        )}

        {/* Error Feedback */}
        {errorMessage && (
          <div className="p-3 bg-red-100 dark:bg-red-950/80 text-red-800 dark:text-red-200 text-xs font-bold rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Primary Action Button: Yazılı Komut */}
      <div className="max-w-md mx-auto">
        <button
          onClick={() => setCurrentView('text')}
          className="w-full flex items-center justify-center gap-2 p-4 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-2xl shadow-md transition-all cursor-pointer text-sm sm:text-base"
        >
          <Keyboard className="w-5 h-5" />
          ✍️ Yazılı Komut
        </button>
      </div>

      {/* Hands-Free Voice Listening Section */}
      <div id="handsfree-section" className="max-w-md mx-auto">
        <HandsFreeWakeWord
          memories={memories}
          reminders={reminders}
          onAddMemory={onAddMemory}
          onAddReminder={onAddReminder}
          onMicStateChange={(active) => setActiveMicState(active)}
          onTranscriptChange={(text) => setWrittenCommand(text)}
        />
      </div>

      {/* Reminders List Section */}
      <div className="bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-3xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Hatırlatıcılar</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Kayıtlı bildirimleriniz</p>
            </div>
          </div>
          <span className="text-xs font-bold text-slate-400">
            {pendingReminders.length} Adet Bekliyor
          </span>
        </div>

        {reminders.length === 0 ? (
          <div className="text-center py-6 px-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 text-xs">
            Henüz eklenmiş bir hatırlatıcı yok.
          </div>
        ) : (
          <div className="space-y-2">
            {reminders.map((r) => {
              const displayObj = formatReminderDisplay(r.dateTime);
              return (
                <div
                  key={r.id}
                  className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                    r.status === 'completed'
                      ? 'bg-slate-100 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                      : 'bg-slate-50 dark:bg-slate-900/80 border-slate-200 dark:border-slate-700/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onToggleReminder(r.id)}
                      className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                        r.status === 'completed'
                          ? 'bg-emerald-500 text-white'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-400 hover:text-emerald-500'
                      }`}
                      title={r.status === 'completed' ? 'Tamamlandı' : 'Tamamlandı yap'}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </button>

                    <div>
                      <p
                        className={`text-sm font-bold text-slate-900 dark:text-white ${
                          r.status === 'completed' ? 'line-through text-slate-400' : ''
                        }`}
                      >
                        🔔 {r.title}
                      </p>
                      <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-amber-500" />
                        {displayObj.fullText}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onDeleteReminder(r.id)}
                    className="p-1.5 text-slate-400 hover:text-red-500 transition-colors cursor-pointer"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Environment Background Notification Note */}
      <div className="p-3 bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 rounded-2xl text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
        <Info className="w-4 h-4 text-indigo-400 shrink-0" />
        <span>
          Bu sürümde arka plan bildirimi bu çalışma ortamında desteklenmiyorsa hatırlatıcı uygulama açıkken ekranda bildirim kartı olarak gösterilir.
        </span>
      </div>
    </div>
  );
};
