import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  isMobileFrame: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, isMobileFrame }) => {
  const [timeString, setTimeString] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!isMobileFrame) {
    return <div className="w-full min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen py-6 px-2 flex items-center justify-center bg-slate-900/90 dark:bg-black/95 transition-all">
      {/* Android Device Mockup Container */}
      <div className="relative w-full max-w-[420px] h-[860px] bg-slate-950 rounded-[48px] shadow-2xl ring-1 ring-slate-800 border-[10px] border-slate-900 flex flex-col overflow-hidden">
        {/* Top Notch / Camera Cutout */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 z-50 w-32 h-6 bg-slate-900 rounded-b-2xl flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-slate-950 ring-1 ring-slate-800" />
        </div>

        {/* Android Status Bar */}
        <div className="w-full h-8 pt-1 px-6 flex items-center justify-between text-[11px] font-mono text-slate-300 z-40 bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-md">
          <span className="font-semibold">{timeString || '12:00'}</span>
          <div className="flex items-center gap-2 text-slate-400">
            <Signal className="w-3 h-3" />
            <Wifi className="w-3 h-3" />
            <Battery className="w-3 h-3 text-emerald-400" />
          </div>
        </div>

        {/* Inner App Content Scroll Area */}
        <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 px-4 pt-2">
          {children}
        </div>

        {/* Android Home Navigation Bar / Pill */}
        <div className="w-full h-6 bg-slate-50 dark:bg-slate-900 flex items-center justify-center z-40">
          <div className="w-32 h-1 bg-slate-400 dark:bg-slate-600 rounded-full opacity-80" />
        </div>
      </div>
    </div>
  );
};
