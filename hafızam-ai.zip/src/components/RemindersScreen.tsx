import React, { useState, useEffect } from 'react';
import { ReminderItem, RepeatFrequency } from '../types';
import {
  Bell,
  Clock,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  ArrowLeft,
  Calendar,
  AlertTriangle,
  Edit3,
  X,
  ShieldAlert,
  Check,
  Sparkles,
  Volume2,
  RotateCw,
} from 'lucide-react';
import {
  getNotificationPermissionStatus,
  requestNotificationPermission,
  NotificationPermissionState,
  formatReminderDisplay,
  playNotificationSound,
} from '../lib/notificationService';

interface RemindersScreenProps {
  onBack: () => void;
  reminders: ReminderItem[];
  onAddReminder: (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => ReminderItem;
  onUpdateReminder: (item: ReminderItem) => void;
  onToggleReminder: (id: string) => void;
  onSnoozeReminder: (id: string, minutes?: number) => void;
  onDeleteReminder: (id: string) => void;
}

export const RemindersScreen: React.FC<RemindersScreenProps> = ({
  onBack,
  reminders,
  onAddReminder,
  onUpdateReminder,
  onToggleReminder,
  onSnoozeReminder,
  onDeleteReminder,
}) => {
  const [activeTab, setActiveTab] = useState<'today' | 'upcoming' | 'recurring' | 'completed'>('today');
  const [newTitle, setNewTitle] = useState('');
  const [newDateTime, setNewDateTime] = useState('');
  const [newRepeatFrequency, setNewRepeatFrequency] = useState<RepeatFrequency>('none');
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermissionState>('default');

  // Modal edit state
  const [editingReminder, setEditingReminder] = useState<ReminderItem | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDateTime, setEditDateTime] = useState('');
  const [editRepeatFrequency, setEditRepeatFrequency] = useState<RepeatFrequency>('none');

  useEffect(() => {
    setPermissionStatus(getNotificationPermissionStatus());
  }, []);

  const handleRequestPermission = async () => {
    const status = await requestNotificationPermission();
    setPermissionStatus(status);
    if (status === 'granted') {
      playNotificationSound();
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    let dateVal = new Date(Date.now() + 3600000).toISOString(); // default +1 hour
    if (newDateTime) {
      dateVal = new Date(newDateTime).toISOString();
    }

    onAddReminder({
      title: newTitle.trim(),
      dateTime: dateVal,
      repeatFrequency: newRepeatFrequency,
    });

    setNewTitle('');
    setNewDateTime('');
    setNewRepeatFrequency('none');
  };

  const handlePresetTime = (hoursFromNow: number, setFixedHour?: number) => {
    const d = new Date();
    if (setFixedHour !== undefined) {
      d.setHours(setFixedHour, 0, 0, 0);
      if (d <= new Date()) {
        d.setDate(d.getDate() + 1);
      }
    } else {
      d.setTime(d.getTime() + hoursFromNow * 3600000);
    }
    // Format to datetime-local string (YYYY-MM-DDTHH:mm)
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    setNewDateTime(`${year}-${month}-${day}T${hours}:${minutes}`);
  };

  const handleOpenEdit = (reminder: ReminderItem) => {
    setEditingReminder(reminder);
    setEditTitle(reminder.title);
    setEditRepeatFrequency(reminder.repeatFrequency || 'none');

    try {
      const d = new Date(reminder.dateTime);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      setEditDateTime(`${year}-${month}-${day}T${hours}:${minutes}`);
    } catch (e) {
      setEditDateTime('');
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingReminder || !editTitle.trim()) return;

    let dateVal = editingReminder.dateTime;
    if (editDateTime) {
      dateVal = new Date(editDateTime).toISOString();
    }

    onUpdateReminder({
      ...editingReminder,
      title: editTitle.trim(),
      dateTime: dateVal,
      repeatFrequency: editRepeatFrequency,
    });

    setEditingReminder(null);
  };

  // Category Filtering
  const todayReminders = reminders.filter((r) => {
    if (r.status === 'completed') return false;
    const fmt = formatReminderDisplay(r.dateTime);
    return fmt.isToday;
  });

  const upcomingReminders = reminders.filter((r) => {
    if (r.status === 'completed') return false;
    const fmt = formatReminderDisplay(r.dateTime);
    return !fmt.isToday;
  });

  const recurringReminders = reminders.filter((r) => r.repeatFrequency && r.repeatFrequency !== 'none');
  const completedReminders = reminders.filter((r) => r.status === 'completed');

  const getDisplayedList = () => {
    switch (activeTab) {
      case 'today':
        return todayReminders;
      case 'upcoming':
        return upcomingReminders;
      case 'recurring':
        return recurringReminders;
      case 'completed':
        return completedReminders;
      default:
        return todayReminders;
    }
  };

  const displayedList = getDisplayedList();

  const getRepeatLabel = (freq?: RepeatFrequency) => {
    switch (freq) {
      case 'daily':
        return '🔁 Her gün';
      case 'weekly':
        return '🔁 Her hafta';
      case 'monthly':
        return '🔁 Her ay';
      default:
        return null;
    }
  };

  const getStatusBadge = (r: ReminderItem) => {
    if (r.status === 'completed') {
      return <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">✓ Tamamlandı</span>;
    }
    if (r.status === 'snoozed') {
      return <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">⏰ Ertelendi</span>;
    }
    if (r.status === 'notified') {
      return <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">🔔 Bildirildi</span>;
    }
    return <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300">Bekliyor</span>;
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      {/* Header Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-amber-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Geri
        </button>
        <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-medium">
          ⏰ AKILLI HATIRLATMALAR
        </span>
      </div>

      {/* Title & Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white rounded-3xl p-6 shadow-lg space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-8 h-8 text-amber-100 animate-pulse" />
            <h2 className="text-2xl font-black">Hatırlatıcılarım</h2>
          </div>

          <button
            onClick={() => playNotificationSound()}
            className="p-2 bg-white/20 hover:bg-white/30 rounded-2xl text-xs font-bold flex items-center gap-1 backdrop-blur-md"
            title="Ses Testi Yap"
          >
            <Volume2 className="w-4 h-4" /> Ses Testi
          </button>
        </div>
        <p className="text-xs text-amber-100 max-w-md">
          Tek seferlik veya tekrar eden tüm hatırlatmalarınızı takip edin, erteleyin veya tamamlayın.
        </p>
      </div>

      {/* NOTIFICATION PERMISSION STATUS BANNER */}
      {permissionStatus === 'granted' ? (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-xs text-emerald-800 dark:text-emerald-300 font-semibold flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            Cihaz/Tarayıcı bildirim izni aktif — Hatırlatmalar zamanında sesli çalacak.
          </span>
          <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded-full font-mono">AKTİF</span>
        </div>
      ) : (
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-xs text-amber-800 dark:text-amber-300 space-y-2">
          <div className="flex items-start gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">⚠️ Bildirim İzni Kapalı veya Verilmedi</p>
              <p className="text-[11px] text-amber-700 dark:text-amber-400">
                Uygulama kapalıyken veya arka plandayken zamanında sesli ve görsel bildirim alabilmek için bildirim izni vermeniz önerilir.
              </p>
            </div>
          </div>
          <button
            onClick={handleRequestPermission}
            className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5"
          >
            <Bell className="w-4 h-4" /> Cihaz Bildirim İznini Etkinleştir
          </button>
        </div>
      )}

      {/* Quick Add Form */}
      <form
        onSubmit={handleAddSubmit}
        className="bg-white dark:bg-slate-800 p-5 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3"
      >
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-amber-500" /> Yeni Hatırlatma Oluştur
          </h4>
        </div>

        {/* Quick presets */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
          <span className="text-slate-400 font-medium">Hızlı Saat:</span>
          <button
            type="button"
            onClick={() => handlePresetTime(1)}
            className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded-lg hover:bg-amber-100 font-medium whitespace-nowrap"
          >
            ⏱️ +1 Saat
          </button>
          <button
            type="button"
            onClick={() => handlePresetTime(3)}
            className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded-lg hover:bg-amber-100 font-medium whitespace-nowrap"
          >
            ⏱️ +3 Saat
          </button>
          <button
            type="button"
            onClick={() => handlePresetTime(0, 20)}
            className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded-lg hover:bg-amber-100 font-medium whitespace-nowrap"
          >
            🌙 Bugün 20:00
          </button>
          <button
            type="button"
            onClick={() => handlePresetTime(24, 9)}
            className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded-lg hover:bg-amber-100 font-medium whitespace-nowrap"
          >
            ☀️ Yarın 09:00
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <input
            type="text"
            required
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="ör. Su iç, İlaçlarımı al..."
            className="sm:col-span-5 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-white"
          />
          <input
            type="datetime-local"
            value={newDateTime}
            onChange={(e) => setNewDateTime(e.target.value)}
            className="sm:col-span-4 px-3 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-white"
          />
          <select
            value={newRepeatFrequency}
            onChange={(e) => setNewRepeatFrequency(e.target.value as RepeatFrequency)}
            className="sm:col-span-3 px-3 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-semibold text-slate-800 dark:text-slate-200"
          >
            <option value="none">Tek Seferlik</option>
            <option value="daily">🔁 Her Gün</option>
            <option value="weekly">🔁 Her Hafta</option>
            <option value="monthly">🔁 Her Ay</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-1 shadow-sm"
        >
          <Plus className="w-4 h-4" /> Hatırlatmayı Kaydet
        </button>
      </form>

      {/* Categorized Tabs Required by User */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-slate-100 dark:bg-slate-800/60 p-1.5 rounded-2xl text-xs font-bold">
        <button
          onClick={() => setActiveTab('today')}
          className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'today'
              ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>Bugün</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
            {todayReminders.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('upcoming')}
          className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'upcoming'
              ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>Yaklaşanlar</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
            {upcomingReminders.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('recurring')}
          className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'recurring'
              ? 'bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>Tekrarlayanlar</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
            {recurringReminders.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('completed')}
          className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'completed'
              ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <span>Tamamlananlar</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
            {completedReminders.length}
          </span>
        </button>
      </div>

      {/* List Display */}
      {displayedList.length === 0 ? (
        <div className="p-8 text-center bg-white dark:bg-slate-800 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 text-slate-500 text-xs space-y-2">
          <Bell className="w-8 h-8 text-slate-400 mx-auto opacity-40" />
          <p className="font-semibold">Bu kategoride henüz hatırlatma bulunmuyor.</p>
          <p className="text-[11px] text-slate-400">
            "Her gün saat 09:00'da ilaçlarımı hatırlat" veya "Bugün saat 20:00'de su içmeyi hatırlat" diyerek sesle hatırlatma ekleyebilirsiniz.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayedList.map((r) => {
            const isDone = r.status === 'completed';
            const displayObj = formatReminderDisplay(r.dateTime);
            const repeatText = getRepeatLabel(r.repeatFrequency);

            return (
              <div
                key={r.id}
                className={`p-4 rounded-3xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800 text-slate-400'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-xs hover:border-amber-400'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => onToggleReminder(r.id)}
                    className="p-1 mt-0.5 text-slate-400 hover:text-emerald-500 transition-colors shrink-0"
                    title={isDone ? 'Bekleyen Olarak İşaretle' : 'Tamamlandı İşaretle'}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-600 hover:text-amber-500" />
                    )}
                  </button>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4
                        className={`text-sm font-bold ${
                          isDone
                            ? 'line-through text-slate-400'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {r.title}
                      </h4>
                      {getStatusBadge(r)}
                      {repeatText && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                          {repeatText}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] text-amber-600 dark:text-amber-400 font-mono flex items-center gap-1 font-bold">
                        <Clock className="w-3 h-3" />
                        {displayObj.fullText}
                      </span>
                      {displayObj.isToday && !isDone && (
                        <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                          BUGÜN
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                  {!isDone && (
                    <>
                      <button
                        onClick={() => onToggleReminder(r.id)}
                        className="px-2.5 py-1.5 bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 text-[11px] font-bold rounded-xl flex items-center gap-1"
                        title="Tamamlandı İşaretle"
                      >
                        <Check className="w-3.5 h-3.5" /> Tamamlandı
                      </button>

                      <button
                        onClick={() => onSnoozeReminder(r.id, 30)}
                        className="px-2.5 py-1.5 bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 hover:bg-amber-100 text-[11px] font-bold rounded-xl flex items-center gap-1"
                        title="30 Dakika Ertele"
                      >
                        <Clock className="w-3.5 h-3.5" /> 30 dk Ertele
                      </button>
                    </>
                  )}

                  <button
                    onClick={() => handleOpenEdit(r)}
                    className="p-1.5 text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 transition-colors"
                    title="Düzenle"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteReminder(r.id)}
                    className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* EDIT MODAL */}
      {editingReminder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl space-y-4 border border-slate-200 dark:border-slate-700 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-500" /> Hatırlatmayı Düzenle
              </h3>
              <button
                onClick={() => setEditingReminder(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Hatırlatma Başlığı
                </label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Tarih ve Saat
                </label>
                <input
                  type="datetime-local"
                  required
                  value={editDateTime}
                  onChange={(e) => setEditDateTime(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Tekrar Sıklığı
                </label>
                <select
                  value={editRepeatFrequency}
                  onChange={(e) => setEditRepeatFrequency(e.target.value as RepeatFrequency)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-semibold text-slate-900 dark:text-white"
                >
                  <option value="none">Tek Seferlik (Tekrar Yok)</option>
                  <option value="daily">🔁 Her Gün</option>
                  <option value="weekly">🔁 Her Hafta (Haftalık)</option>
                  <option value="monthly">🔁 Her Ay (Aylık)</option>
                </select>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingReminder(null)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-semibold"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-bold"
                >
                  Güncelle & Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
