import React, { useState, useEffect } from 'react';
import { VolumeX, ShieldAlert } from 'lucide-react';
import { getSilentReminderEnabled, setSilentReminderEnabled, isNativeSilentModeAvailable } from '../lib/silentModeService';

export const SilentModeSetting: React.FC = () => {
  const [isEnabled, setIsEnabled] = useState<boolean>(true);
  const [isNative, setIsNative] = useState<boolean>(false);

  useEffect(() => {
    setIsNative(isNativeSilentModeAvailable());
    getSilentReminderEnabled().then((val) => setIsEnabled(val));
  }, []);

  const handleToggle = async () => {
    const nextVal = !isEnabled;
    setIsEnabled(nextVal);
    await setSilentReminderEnabled(nextVal);
  };

  return (
    <div className="bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-3xl p-4 shadow-sm space-y-2 transition-all">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-2xl transition-colors ${
            isEnabled
              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
              : 'bg-slate-100 dark:bg-slate-700/50 text-slate-400'
          }`}>
            <VolumeX className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              Sessiz Mod Hatırlatıcısı
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Telefonun 30 dakika boyunca sessizde kalırsa seni uyarır.
            </p>
          </div>
        </div>

        {/* Toggle Switch */}
        <button
          type="button"
          onClick={handleToggle}
          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
            isEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'
          }`}
          role="switch"
          aria-checked={isEnabled}
        >
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
              isEnabled ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {!isNative && (
        <div className="text-[11px] text-slate-400 dark:text-slate-500 pt-1 flex items-center gap-1">
          <ShieldAlert className="w-3.5 h-3.5 shrink-0 text-slate-400" />
          <span>(Bu özellik gerçek Android APK / cihaz üzerinde çalışır)</span>
        </div>
      )}
    </div>
  );
};
