import React, { useState, useEffect, useRef } from 'react';
import { processAIQuery, speakText, stopSpeaking } from '../lib/aiService';
import { MemoryItem, ReminderItem, ProcessAIResponse } from '../types';
import { Mic, MicOff, Volume2, VolumeX, ArrowLeft, Brain, Sparkles, Check, Send, AlertCircle, RefreshCw, Radio } from 'lucide-react';
import { PrivacyBadge } from './PrivacyBadge';
import { formatReminderDisplay } from '../lib/notificationService';

interface VoiceModalProps {
  onBack: () => void;
  memories: MemoryItem[];
  reminders: ReminderItem[];
  onAddMemory: (item: Omit<MemoryItem, 'id' | 'createdAt'>) => MemoryItem;
  onAddReminder: (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => ReminderItem;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({
  onBack,
  memories,
  reminders,
  onAddMemory,
  onAddReminder,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [manualText, setManualText] = useState('');
  const [statusText, setStatusText] = useState<'idle' | 'listening' | 'processing' | 'done' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [aiResponse, setAiResponse] = useState<ProcessAIResponse | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [savedSuccessBadge, setSavedSuccessBadge] = useState<string | null>(null);
  const [audioLevel, setAudioLevel] = useState<number>(0);

  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const silenceTimerRef = useRef<any>(null);
  const isProcessingRef = useRef<boolean>(false);

  // Helper to extract clean command removing wake word prefix like "Hey Hafızam" or "Merhaba Hafızam"
  const extractCleanCommand = (text: string): string => {
    let clean = text.trim();
    const wakeRegex = /^(hey\s*hafızam|hey\s*hafizam|merhaba\s*hafızam|merhaba\s*hafizam|\bhafızam\b|\bhafizam\b)[,\s.-]*/i;
    clean = clean.replace(wakeRegex, '').trim();
    if (clean.length > 0) {
      clean = clean.charAt(0).toUpperCase() + clean.slice(1);
    }
    return clean;
  };

  // Clean up Audio Analysis
  const stopAudioAnalysis = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch (e) {}
      audioContextRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setAudioLevel(0);
  };

  // Start Audio Analysis for VAD & volume meter
  const startAudioAnalysis = async (): Promise<boolean> => {
    stopAudioAnalysis();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        audioContextRef.current = audioCtx;
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        source.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);

        const checkVolume = () => {
          if (!mediaStreamRef.current) return;
          analyser.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const average = sum / dataArray.length;
          const normalized = Math.min(100, Math.round((average / 128) * 100));
          setAudioLevel(normalized);

          animFrameRef.current = requestAnimationFrame(checkVolume);
        };
        checkVolume();
      }
      return true;
    } catch (err) {
      console.error('Mic access error in VoiceModal:', err);
      setErrorMessage('Mikrofon izni alınamadı. Lütfen tarayıcı iznini kontrol edin.');
      return false;
    }
  };

  const handleStopListening = () => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
    stopAudioAnalysis();
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
      } catch (e) {}
      recognitionRef.current = null;
    }
    setIsListening(false);
  };

  const handleStartListening = async () => {
    handleStopListening();
    setErrorMessage(null);
    setAiResponse(null);
    setSavedSuccessBadge(null);

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMessage('Tarayıcınız ses tanıma özelliğini desteklemiyor.');
      return;
    }

    // Pre-warm audio stream for Android / browser compatibility
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (err: any) {
        console.warn('getUserMedia mic request in VoiceModal:', err);
        if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
          setErrorMessage('Mikrofon izni engellendi.');
          setStatusText('error');
          return;
        }
      }
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'tr-TR';

    let collectedText = '';

    recognition.onstart = () => {
      setIsListening(true);
      setStatusText('listening');
      setTranscript('');
    };

    recognition.onresult = (event: any) => {
      let fullTranscript = '';
      for (let i = 0; i < event.results.length; i++) {
        fullTranscript += event.results[i][0].transcript;
      }

      if (fullTranscript.trim()) {
        collectedText = fullTranscript.trim();
        setTranscript(collectedText);

        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          try {
            recognition.stop();
          } catch (e) {}
        }, 2800);
      }
    };

    recognition.onspeechend = () => {
      try {
        recognition.stop();
      } catch (e) {}
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech error in VoiceModal:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        handleStopListening();
        setErrorMessage('Mikrofon izni engellendi.');
        setStatusText('error');
        return;
      }

      if (event.error === 'no-speech' || event.error === 'aborted') {
        return;
      }

      handleStopListening();
      if (collectedText.trim()) {
        handleProcessText(collectedText.trim());
      } else {
        setStatusText('error');
        setErrorMessage('Konuşma metne dönüştürülemedi.');
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      const finalText = collectedText.trim();
      if (finalText) {
        handleProcessText(finalText);
      } else if (statusText === 'listening') {
        setStatusText('idle');
      }
    };

    recognitionRef.current = recognition;

    try {
      recognition.start();
    } catch (e) {
      console.error('Start recognition error:', e);
      setStatusText('error');
      setErrorMessage('Konuşma metne dönüştürülemedi.');
    }
  };

  const handleProcessText = async (textToProcess: string) => {
    if (isProcessingRef.current) return;

    const cleanText = extractCleanCommand(textToProcess);
    if (!cleanText.trim()) return;

    isProcessingRef.current = true;
    handleStopListening();
    setTranscript(cleanText);
    setStatusText('processing');
    setSavedSuccessBadge(null);
    setErrorMessage(null);

    try {
      const result = await processAIQuery({
        prompt: cleanText,
        currentMemories: memories,
        currentReminders: reminders,
      });

      setAiResponse(result);

      // Determine reminder data to save
      const isRemindCommand =
        result.intent === 'remind' ||
        cleanText.toLowerCase().includes('hatırlat') ||
        cleanText.toLowerCase().includes('uyandır') ||
        cleanText.toLowerCase().includes('alarm');

      const reminderData =
        result.reminderToSave ||
        (isRemindCommand
          ? {
              title:
                cleanText
                  .replace(/(bana|hatırlat|uyandır|alarm|kur|bugün|yarın|saat|\d{1,2}[:.]\d{2}|lütfen)/gi, '')
                  .trim() || 'Hatırlatma',
              dateTime: new Date(Date.now() + 3600000).toISOString(),
              repeatFrequency: 'none' as const,
            }
          : null);

      if (reminderData) {
        const created = onAddReminder({
          title: reminderData.title || 'Hatırlatma',
          dateTime: reminderData.dateTime || new Date(Date.now() + 3600000).toISOString(),
          repeatFrequency: reminderData.repeatFrequency || 'none',
        });

        const fmtObj = formatReminderDisplay(created.dateTime);
        let badgeMsg = `🔔 Hatırlatma oluşturuldu — ${fmtObj.fullText}`;

        if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission !== 'granted') {
          badgeMsg += ' (⚠️ Bildirim izni verilmedi)';
        }

        setSavedSuccessBadge(badgeMsg);
      } else if (
        (result.intent === 'remember' || cleanText.toLowerCase().includes('hatırla') || cleanText.toLowerCase().includes('kaydet')) &&
        result.memoryToSave
      ) {
        onAddMemory({
          title: result.memoryToSave.title,
          content: result.memoryToSave.content,
          category: result.memoryToSave.category || 'Not',
          tags: result.memoryToSave.tags || ['sesli-komut'],
          source: 'voice',
        });
        setSavedSuccessBadge(`🧠 '${result.memoryToSave.title}' Hafızam'a kaydedildi`);
      }

      setStatusText('done');

      // Speak response out loud in Turkish
      if (result.speechText || result.responseText) {
        const textToSpeak = result.speechText || result.responseText;
        setIsPlayingAudio(true);
        speakText(textToSpeak, () => setIsPlayingAudio(false));
      }
    } catch (err) {
      console.error('Voice process error:', err);
      setStatusText('error');
      setErrorMessage('Komut işlenirken bir sorun oluştu.');
    } finally {
      isProcessingRef.current = false;
    }
  };

  const handlePresetCommand = (cmd: string) => {
    setTranscript(cmd);
    handleProcessText(cmd);
  };

  const handleToggleSpeak = () => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
    } else if (aiResponse) {
      const textToSpeak = aiResponse.speechText || aiResponse.responseText;
      setIsPlayingAudio(true);
      speakText(textToSpeak, () => setIsPlayingAudio(false));
    }
  };

  useEffect(() => {
    return () => {
      stopSpeaking();
      handleStopListening();
    };
  }, []);

  return (
    <div className="space-y-6 pb-8 animate-fade-in">
      {/* Header Back & Privacy */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400"
        >
          <ArrowLeft className="w-4 h-4" /> Geri
        </button>
        <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-medium">
          🎙️ SESLİ ASİSTAN
        </span>
      </div>

      <PrivacyBadge activeMic={isListening} />

      {/* Main Voice Activation Portal */}
      <div className="bg-gradient-to-b from-indigo-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 text-center space-y-6 shadow-xl border border-indigo-800/40 relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-2 relative z-10">
          <h3 className="text-2xl font-black tracking-tight text-white">Sesinle Komut Ver</h3>
          <p className="text-xs text-indigo-200 max-w-xs mx-auto">
            Düğmeye bas ve ne hatırlamak veya öğrenmek istediğini söyle.
          </p>
        </div>

        {/* Dynamic Mic Wave Button */}
        <div className="relative z-10 my-4 flex flex-col items-center justify-center">
          {isListening && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <span className="w-32 h-32 bg-indigo-500/30 rounded-full animate-ping" />
              <span className="w-40 h-40 bg-purple-500/20 rounded-full animate-pulse" />
            </div>
          )}

          <button
            onClick={isListening ? handleStopListening : handleStartListening}
            className={`relative z-20 w-24 h-24 rounded-full flex items-center justify-center transition-all transform active:scale-95 shadow-2xl ${
              isListening
                ? 'bg-red-500 hover:bg-red-600 text-white ring-8 ring-red-500/30'
                : 'bg-gradient-to-tr from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white shadow-indigo-500/40 ring-4 ring-indigo-400/20'
            }`}
          >
            <Mic className={`w-10 h-10 ${isListening ? 'animate-bounce' : ''}`} />
          </button>

          <span className="mt-4 text-xs font-semibold tracking-wider uppercase text-indigo-200 font-mono">
            {isListening
              ? '🎙️ Dinliyorum...'
              : statusText === 'processing'
              ? '🧠 Düşünüyorum...'
              : 'Düğmeye basarak konuşun'}
          </span>

          {/* Volume Meter */}
          {isListening && (
            <div className="w-48 mt-3 bg-indigo-950/80 border border-indigo-700/60 p-2 rounded-xl flex items-center gap-2">
              <Volume2 className="w-3.5 h-3.5 text-indigo-300 shrink-0" />
              <div className="flex-1 bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-400 h-full transition-all duration-75 rounded-full"
                  style={{ width: `${Math.max(5, audioLevel)}%` }}
                />
              </div>
              <span className="text-[10px] font-mono text-indigo-300">
                {audioLevel > 10 ? 'Ses Algılandı' : 'Sessiz'}
              </span>
            </div>
          )}
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-red-900/60 border border-red-500/40 rounded-2xl text-xs text-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Live Speech-to-Text Command Box */}
        <div className="bg-slate-900/90 border border-indigo-500/40 rounded-2xl p-4 text-left space-y-2 text-xs backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-mono font-bold text-indigo-300 block">Algılanan Komut Metni:</span>
            {transcript && (
              <span className="text-[10px] text-emerald-400 font-mono font-bold flex items-center gap-1">
                <Check className="w-3 h-3" /> Metne Dönüştürüldü
              </span>
            )}
          </div>

          <textarea
            rows={2}
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            placeholder="Konuşmaya başladığınızda söyledikleriniz burada otomatik belirecek... (Örn: 'Bugün saat 21:00\'de bana su içmeyi hatırlat.')"
            className="w-full p-2.5 bg-slate-950/80 border border-indigo-700/60 rounded-xl text-sm font-semibold text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-400 transition-all resize-none leading-snug"
          />

          {!isListening && transcript && statusText !== 'processing' && (
            <div className="pt-1 flex justify-end">
              <button
                onClick={() => handleProcessText(transcript)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" /> HAFIZAM'a Gönder
              </button>
            </div>
          )}
        </div>

        {/* Quick Voice Simulation Shortcuts */}
        <div className="pt-2 text-left space-y-2 border-t border-indigo-800/40">
          <span className="text-[11px] font-semibold text-indigo-300">Örnek Sesli Komutlar:</span>
          <div className="flex flex-wrap gap-1.5">
            {[
              'Bugün saat 21:00\'de bana su içmeyi hatırlat',
              'Bu kombi şifresini hatırla',
              'Yarın saat 14:00\'te elektrik faturasını hatırlat',
              'Geçen ay kaydettiğim klimayı bul',
            ].map((cmd, idx) => (
              <button
                key={idx}
                onClick={() => handlePresetCommand(cmd)}
                className="px-2.5 py-1.5 bg-indigo-950/80 hover:bg-indigo-800/60 border border-indigo-700/50 rounded-xl text-indigo-100 text-[11px] transition-colors"
              >
                🗣️ "{cmd}"
              </button>
            ))}
          </div>
        </div>

        {/* Manual Text Option in Voice Screen */}
        <div className="flex items-center gap-2 pt-2">
          <input
            type="text"
            value={manualText}
            onChange={(e) => setManualText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                setTranscript(manualText);
                handleProcessText(manualText);
                setManualText('');
              }
            }}
            placeholder="Veya yazarak sesli komut gönder..."
            className="flex-1 px-3.5 py-2.5 bg-slate-900/90 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-400"
          />
          <button
            onClick={() => {
              if (manualText.trim()) {
                setTranscript(manualText);
                handleProcessText(manualText);
                setManualText('');
              }
            }}
            className="p-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-white transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* RESULT DISPLAY CARD */}
      {statusText === 'processing' && (
        <div className="p-6 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-3xl text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-indigo-600 dark:text-indigo-400 animate-spin mx-auto" />
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            🧠 “Düşünüyorum…”
          </p>
        </div>
      )}

      {aiResponse && (
        <div className="bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-3xl p-5 shadow-lg space-y-4 animate-fade-in">
          {/* Status Badge */}
          {savedSuccessBadge && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-3 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                {savedSuccessBadge}
              </span>
              <span className="text-[10px] text-emerald-600 font-mono">✓ TAMAMLANTI</span>
            </div>
          )}

          {/* AI Response Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                <Brain className="w-4 h-4" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">HAFIZAM AI Yanıtı</h4>
            </div>

            <button
              onClick={handleToggleSpeak}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                isPlayingAudio
                  ? 'bg-amber-500 text-white animate-pulse'
                  : 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100'
              }`}
            >
              {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              {isPlayingAudio ? 'Durdur' : 'Sesli Oku'}
            </button>
          </div>

          <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-100 dark:border-slate-700/60 whitespace-pre-wrap">
            {aiResponse.responseText}
          </p>
        </div>
      )}
    </div>
  );
};
