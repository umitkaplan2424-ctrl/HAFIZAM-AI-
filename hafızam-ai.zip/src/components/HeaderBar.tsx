import React, { useState, useEffect } from 'react';
import { AppView } from '../types';
import { Brain, ArrowLeft, Moon, Sun, Bell, Shield, Smartphone, Radio } from 'lucide-react';

interface HeaderBarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  pendingRemindersCount: number;
  isMobileFrame: boolean;
  setIsMobileFrame: (val: boolean) => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentView,
  setCurrentView,
  darkMode,
  setDarkMode,
  pendingRemindersCount,
  isMobileFrame,
  setIsMobileFrame,
}) => {
  const isHome = currentView === 'home';
  const [isHandsFreeActive, setIsHandsFreeActive] = useState(false);

  useEffect(() => {
    const checkStatus = () => {
      try {
        setIsHandsFreeActive(localStorage.getItem('hafizam_handsfree_enabled') === 'true');
      } catch {}
    };

    checkStatus();
    const interval = setInterval(checkStatus, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Left: Back button or Logo */}
        <div className="flex items-center gap-2.5">
          {!isHome ? (
            <button
              onClick={() => setCurrentView('home')}
              className="p-2 -ml-1 rounded-xl bg-slate-200/60 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1 text-sm font-medium"
              title="Ana Ekrana Dön"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden sm:inline">Ana Ekran</span>
            </button>
          ) : (
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                <Brain className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                  HAFIZAM <span className="text-xs px-1.5 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-mono">AI</span>
                </h1>
              </div>
            </div>
          )}
        </div>

        {/* Center/Right: Handsfree Active Indicator Badge */}
        {isHandsFreeActive && (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold">
            <Radio className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
            <span>“Hey Hafızam” Dinleniyor</span>
          </div>
        )}

        {/* Right Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Reminders Quick Access */}
          <button
            onClick={() => setCurrentView('reminders')}
            className={`relative p-2.5 rounded-xl transition-all ${
              currentView === 'reminders'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-200/50 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
            }`}
            title="Hatırlatmalar"
          >
            <Bell className="w-4 h-4" />
            {pendingRemindersCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-slate-50 dark:border-slate-900">
                {pendingRemindersCount}
              </span>
            )}
          </button>

          {/* Toggle Device Frame / Full View */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className={`p-2.5 rounded-xl transition-all ${
              isMobileFrame
                ? 'bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800'
                : 'bg-slate-200/50 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
            }`}
            title={isMobileFrame ? 'Geniş Görünüme Geç' : 'Telefon Görünümüne Geç'}
          >
            <Smartphone className="w-4 h-4" />
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2.5 rounded-xl bg-slate-200/50 dark:bg-slate-800/70 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
            title={darkMode ? 'Açık Temaya Geç' : 'Koyu Temaya Geç'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>
        </div>
      </div>
    </header>
  );
};
