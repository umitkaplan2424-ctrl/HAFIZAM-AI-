import React, { useState, useEffect } from 'react';
import { AppView, MemoryItem, ReminderItem } from './types';
import {
  getMemories,
  addMemory,
  deleteMemory,
  getReminders,
  addReminder,
  toggleReminderStatus,
  snoozeReminder,
  completeReminder,
  deleteReminder,
} from './lib/storage';
import {
  startNotificationScheduler,
  stopNotificationScheduler,
  scheduleNativeLocalNotification,
  cancelNativeLocalNotification,
  setupNativeNotificationListeners,
} from './lib/notificationService';
import { speakText } from './lib/aiService';

import { AndroidFrame } from './components/AndroidFrame';
import { HeaderBar } from './components/HeaderBar';
import { HomeScreen } from './components/HomeScreen';
import { TextModal } from './components/TextModal';
import { VoiceModal } from './components/VoiceModal';
import { RemindersScreen } from './components/RemindersScreen';
import { Bell, Clock, Trash2, X, Check } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(true);

  // Storage States
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [reminders, setReminders] = useState<ReminderItem[]>([]);

  // Active Trigger Toast Popup & Last Triggered Reminder Tracker
  const [activeTriggerToast, setActiveTriggerToast] = useState<ReminderItem | null>(null);
  const [lastTriggeredReminderId, setLastTriggeredReminderId] = useState<string | null>(null);

  // Initial Load & Scheduler Setup
  useEffect(() => {
    setMemories(getMemories());
    const initialReminders = getReminders();
    setReminders(initialReminders);

    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }

    // Register native notification listeners for Android actions
    setupNativeNotificationListeners(
      (reminderId) => handleCompleteReminder(reminderId),
      (reminderId, mins) => handleSnoozeReminder(reminderId, mins),
      (reminderId) => handleDeleteReminder(reminderId)
    );

    // Sync future reminders to native notification scheduler
    initialReminders.forEach((r) => {
      if (r.status === 'pending' || r.status === 'snoozed') {
        scheduleNativeLocalNotification(r);
      }
    });

    // Start background alarm scheduler loop
    startNotificationScheduler(
      () => getReminders(),
      (triggeredReminder) => {
        setActiveTriggerToast(triggeredReminder);
        setLastTriggeredReminderId(triggeredReminder.id);
        setReminders(getReminders());
      }
    );

    return () => {
      stopNotificationScheduler();
    };
  }, []);

  // Sync dark mode class on html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Memory Handlers
  const handleAddMemory = (item: Omit<MemoryItem, 'id' | 'createdAt'>) => {
    const created = addMemory(item);
    setMemories(getMemories());
    return created;
  };

  // Reminder Handlers
  const handleAddReminder = (item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>) => {
    const isSnoozeCommand =
      item.title.startsWith('__SNOOZE_') ||
      item.title.toLowerCase().includes('ertele') ||
      item.title.toLowerCase().includes('tekrar');

    if (isSnoozeCommand) {
      let snoozeMins = 30;

      if (item.title.startsWith('__SNOOZE_')) {
        const parsed = parseInt(item.title.replace('__SNOOZE_', '').replace('__', ''), 10);
        if (!isNaN(parsed) && parsed > 0) {
          snoozeMins = parsed;
        }
      } else if (item.dateTime && !isNaN(parseInt(item.dateTime, 10)) && parseInt(item.dateTime, 10) > 0 && parseInt(item.dateTime, 10) < 10000) {
        snoozeMins = parseInt(item.dateTime, 10);
      } else {
        const lower = item.title.toLowerCase();
        if (lower.includes('yarım saat')) snoozeMins = 30;
        else if (lower.includes('yarın')) snoozeMins = 1440;
        else if (lower.includes('bir saat') || lower.includes('1 saat')) snoozeMins = 60;
        else {
          const hMatch = lower.match(/(\d+)\s*saat/);
          const mMatch = lower.match(/(\d+)\s*(dakika|dk)/);
          if (hMatch) snoozeMins = parseInt(hMatch[1], 10) * 60;
          else if (mMatch) snoozeMins = parseInt(mMatch[1], 10);
        }
      }

      if (isNaN(snoozeMins) || snoozeMins <= 0) snoozeMins = 30;

      const currentReminders = getReminders();

      // Priority: 1) activeTriggerToast ID, 2) lastTriggeredReminderId, 3) last notified/snoozed reminder
      const targetId = activeTriggerToast?.id || lastTriggeredReminderId;
      let targetReminder = currentReminders.find((r) => r.id === targetId);

      if (!targetReminder) {
        const notifiedList = currentReminders.filter((r) => r.status === 'notified' || r.status === 'snoozed');
        if (notifiedList.length > 0) {
          targetReminder = notifiedList[notifiedList.length - 1];
        }
      }

      if (targetReminder) {
        const updatedList = snoozeReminder(targetReminder.id, snoozeMins);
        setReminders(updatedList);
        setLastTriggeredReminderId(targetReminder.id);

        const snoozedItem = updatedList.find((r) => r.id === targetReminder!.id);
        if (snoozedItem) {
          scheduleNativeLocalNotification(snoozedItem);
        }

        if (activeTriggerToast && activeTriggerToast.id === targetReminder.id) {
          setActiveTriggerToast(null);
        }

        const durationText =
          snoozeMins >= 1440
            ? `${Math.round(snoozeMins / 1440)} gün`
            : snoozeMins >= 60
            ? `${Math.round(snoozeMins / 60)} saat`
            : `${snoozeMins} dakika`;

        speakText(`Tamam, ${targetReminder.title} ${durationText} ertelendi.`);

        return targetReminder;
      } else {
        speakText('Erteleyebileceğim aktif bir hatırlatıcı bulamadım.');
        return {
          id: 'no-target',
          title: 'Erteleme',
          dateTime: new Date().toISOString(),
          status: 'snoozed',
          createdAt: new Date().toISOString(),
        };
      }
    }

    const created = addReminder(item);
    setReminders(getReminders());
    scheduleNativeLocalNotification(created);
    return created;
  };

  const handleToggleReminder = (id: string) => {
    const updated = toggleReminderStatus(id);
    setReminders(updated);
    const item = updated.find((r) => r.id === id);
    if (item && (item.status === 'pending' || item.status === 'snoozed')) {
      scheduleNativeLocalNotification(item);
    } else {
      cancelNativeLocalNotification(id);
    }
  };

  const handleSnoozeReminder = (id: string, minutes: number = 30) => {
    const updated = snoozeReminder(id, minutes);
    setReminders(updated);
    setLastTriggeredReminderId(id);
    const snoozedItem = updated.find((r) => r.id === id);
    if (snoozedItem) {
      scheduleNativeLocalNotification(snoozedItem);
    }
    if (activeTriggerToast && activeTriggerToast.id === id) {
      setActiveTriggerToast(null);
    }
  };

  const handleCompleteReminder = (id: string) => {
    const updated = completeReminder(id);
    setReminders(updated);
    cancelNativeLocalNotification(id);
    if (activeTriggerToast && activeTriggerToast.id === id) {
      setActiveTriggerToast(null);
    }
  };

  const handleDeleteReminder = (id: string) => {
    deleteReminder(id);
    setReminders(getReminders());
    cancelNativeLocalNotification(id);
    if (activeTriggerToast && activeTriggerToast.id === id) {
      setActiveTriggerToast(null);
    }
  };

  const pendingRemindersCount = reminders.filter((r) => r.status === 'pending').length;

  return (
    <div className={`min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors`}>
      <AndroidFrame isMobileFrame={isMobileFrame}>
        <div className="min-h-full flex flex-col relative">
          {/* Active Trigger Toast Popup */}
          {activeTriggerToast && (
            <div className="sticky top-0 z-50 p-3 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white shadow-2xl animate-fade-in space-y-2 border-b border-amber-500">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs sm:text-sm font-bold">
                  <Bell className="w-5 h-5 text-amber-200 animate-pulse shrink-0" />
                  <div>
                    <p className="font-black text-amber-200 uppercase text-[10px] tracking-wider">🔔 HATIRLATMA ZAMANI GELDI!</p>
                    <p className="text-sm font-black">{activeTriggerToast.title}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTriggerToast(null)}
                  className="p-1 bg-white/20 hover:bg-white/30 rounded-lg text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-end gap-1.5 pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => handleCompleteReminder(activeTriggerToast.id)}
                  className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" /> ✓ Tamamlandı
                </button>

                <button
                  type="button"
                  onClick={() => handleSnoozeReminder(activeTriggerToast.id, 30)}
                  className="px-3 py-1.5 bg-amber-800 hover:bg-amber-900 text-amber-100 font-bold rounded-xl flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                >
                  <Clock className="w-3.5 h-3.5" /> ⏰ 30 dk ertele
                </button>

                <button
                  type="button"
                  onClick={() => handleDeleteReminder(activeTriggerToast.id)}
                  className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                  title="Sil"
                >
                  <Trash2 className="w-3.5 h-3.5" /> 🗑 Sil
                </button>
              </div>
            </div>
          )}

          <HeaderBar
            currentView={currentView}
            setCurrentView={setCurrentView}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            pendingRemindersCount={pendingRemindersCount}
            isMobileFrame={isMobileFrame}
            setIsMobileFrame={setIsMobileFrame}
          />

          <main className="flex-1 p-3 sm:p-4 max-w-2xl mx-auto w-full">
            {currentView === 'home' && (
              <HomeScreen
                setCurrentView={setCurrentView}
                reminders={reminders}
                onToggleReminder={handleToggleReminder}
                onAddReminder={handleAddReminder}
                onDeleteReminder={handleDeleteReminder}
                memories={memories}
                onAddMemory={handleAddMemory}
              />
            )}

            {currentView === 'text' && (
              <TextModal
                onBack={() => setCurrentView('home')}
                memories={memories}
                reminders={reminders}
                onAddMemory={handleAddMemory}
                onAddReminder={handleAddReminder}
              />
            )}

            {currentView === 'voice' && (
              <VoiceModal
                onBack={() => setCurrentView('home')}
                memories={memories}
                reminders={reminders}
                onAddMemory={handleAddMemory}
                onAddReminder={handleAddReminder}
              />
            )}

            {currentView === 'reminders' && (
              <RemindersScreen
                onBack={() => setCurrentView('home')}
                reminders={reminders}
                onAddReminder={handleAddReminder}
                onUpdateReminder={() => {}}
                onToggleReminder={handleToggleReminder}
                onSnoozeReminder={handleSnoozeReminder}
                onDeleteReminder={handleDeleteReminder}
              />
            )}
          </main>
        </div>
      </AndroidFrame>
    </div>
  );
}
