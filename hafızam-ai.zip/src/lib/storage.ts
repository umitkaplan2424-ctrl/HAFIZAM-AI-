import { MemoryItem, ReminderItem } from '../types';

const MEMORIES_KEY = 'hafizam_ai_memories_v1';
const REMINDERS_KEY = 'hafizam_ai_reminders_v1';

const INITIAL_MEMORIES: MemoryItem[] = [
  {
    id: 'mem-1',
    title: 'Ev İnternet Müşteri No ve Şifre',
    content: 'Müşteri No: 8849201938, Wi-Fi Şifresi: HafizamSuper2026!',
    category: 'Not',
    tags: ['internet', 'wifi', 'şifre'],
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    source: 'text',
  },
  {
    id: 'mem-2',
    title: 'Oturma Odası Klima Garanti Belgeli Seri No',
    content: 'Marka: Arçelik Ekolog 12000 BTU, Seri No: AR-99201-XK, Garanti Bitiş: 12 Kasım 2027.',
    category: 'Cihaz',
    tags: ['klima', 'garanti', 'arçelik'],
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
    source: 'camera',
  },
  {
    id: 'mem-3',
    title: 'Site Yönetimi Aidat Faturası',
    content: 'Ağustos 2026 Aidatı: 1.250 TL, İBAN: TR89 0006 2000 0001 2345 6789 01 - Evren Apt.',
    category: 'Fatura',
    tags: ['aidat', 'fatura', 'iban'],
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    source: 'camera',
  },
  {
    id: 'mem-4',
    title: 'Arabamın Lastik Ebatları ve Muayene Tarihi',
    content: 'Lastik: 205/55 R16 91V, Muayene geçerlilik tarihi: 15 Ekim 2026.',
    category: 'Ürün',
    tags: ['araba', 'lastik', 'muayene'],
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
    source: 'voice',
  },
];

const INITIAL_REMINDERS: ReminderItem[] = [
  {
    id: 'rem-1',
    title: 'Kombinin yıllık bakım servisini ara',
    dateTime: new Date(Date.now() + 3600000 * 4).toISOString(), // today in 4 hours
    status: 'pending',
    repeatFrequency: 'none',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rem-2',
    title: 'Ağustos ayı elektrik faturasını öde',
    dateTime: new Date(Date.now() + 86400000).toISOString(), // tomorrow
    status: 'pending',
    repeatFrequency: 'monthly',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rem-3',
    title: 'Eczaneden vitamin spreyini al',
    dateTime: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'completed',
    repeatFrequency: 'none',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'rem-4',
    title: 'Her gün sabah 09:00 ilacımı iç',
    dateTime: new Date(Date.now() + 1800000).toISOString(),
    status: 'pending',
    repeatFrequency: 'daily',
    createdAt: new Date().toISOString(),
  },
];

export function getMemories(): MemoryItem[] {
  try {
    const data = localStorage.getItem(MEMORIES_KEY);
    if (!data) {
      localStorage.setItem(MEMORIES_KEY, JSON.stringify(INITIAL_MEMORIES));
      return INITIAL_MEMORIES;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load memories from localStorage', e);
    return INITIAL_MEMORIES;
  }
}

export function saveMemories(memories: MemoryItem[]): void {
  try {
    localStorage.setItem(MEMORIES_KEY, JSON.stringify(memories));
  } catch (e) {
    console.error('Failed to save memories to localStorage', e);
  }
}

export function addMemory(item: Omit<MemoryItem, 'id' | 'createdAt'>): MemoryItem {
  const current = getMemories();
  const newItem: MemoryItem = {
    ...item,
    id: 'mem-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
    createdAt: new Date().toISOString(),
  };
  const updated = [newItem, ...current];
  saveMemories(updated);
  return newItem;
}

export function updateMemory(updatedItem: MemoryItem): void {
  const current = getMemories();
  const index = current.findIndex((m) => m.id === updatedItem.id);
  if (index !== -1) {
    current[index] = updatedItem;
    saveMemories(current);
  }
}

export function deleteMemory(id: string): void {
  const current = getMemories();
  const updated = current.filter((m) => m.id !== id);
  saveMemories(updated);
}

export function clearAllMemories(): void {
  localStorage.setItem(MEMORIES_KEY, JSON.stringify([]));
  localStorage.setItem(REMINDERS_KEY, JSON.stringify([]));
}

// Reminders
export function getReminders(): ReminderItem[] {
  try {
    const data = localStorage.getItem(REMINDERS_KEY);
    if (!data) {
      localStorage.setItem(REMINDERS_KEY, JSON.stringify(INITIAL_REMINDERS));
      return INITIAL_REMINDERS;
    }
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to load reminders from localStorage', e);
    return INITIAL_REMINDERS;
  }
}

export function saveReminders(reminders: ReminderItem[]): void {
  try {
    localStorage.setItem(REMINDERS_KEY, JSON.stringify(reminders));
  } catch (e) {
    console.error('Failed to save reminders to localStorage', e);
  }
}

export function calculateNextOccurrence(isoDateStr: string, freq?: 'none' | 'daily' | 'weekly' | 'monthly'): string {
  if (!freq || freq === 'none') return isoDateStr;

  const currentD = new Date(isoDateStr);
  const baseD = isNaN(currentD.getTime()) ? new Date() : currentD;
  const now = new Date();

  const nextD = new Date(baseD);

  if (freq === 'daily') {
    nextD.setDate(nextD.getDate() + 1);
  } else if (freq === 'weekly') {
    nextD.setDate(nextD.getDate() + 7);
  } else if (freq === 'monthly') {
    nextD.setMonth(nextD.getMonth() + 1);
  }

  // If nextD is still in the past, adjust it relative to now
  while (nextD <= now) {
    if (freq === 'daily') nextD.setDate(nextD.getDate() + 1);
    else if (freq === 'weekly') nextD.setDate(nextD.getDate() + 7);
    else if (freq === 'monthly') nextD.setMonth(nextD.getMonth() + 1);
  }

  return nextD.toISOString();
}

export function addReminder(item: Omit<ReminderItem, 'id' | 'createdAt' | 'status'>): ReminderItem {
  const current = getReminders();
  const newItem: ReminderItem = {
    ...item,
    repeatFrequency: item.repeatFrequency || 'none',
    id: 'rem-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
    status: 'pending',
    createdAt: new Date().toISOString(),
  };
  const updated = [newItem, ...current];
  saveReminders(updated);
  return newItem;
}

export function updateReminder(updatedItem: ReminderItem): void {
  const current = getReminders();
  const index = current.findIndex((r) => r.id === updatedItem.id);
  if (index !== -1) {
    current[index] = updatedItem;
    saveReminders(current);
  }
}

export function snoozeReminder(id: string, minutes: number = 30): ReminderItem[] {
  const current = getReminders();
  const snoozeTime = new Date(Date.now() + minutes * 60000).toISOString();
  const updated = current.map((r) =>
    r.id === id
      ? {
          ...r,
          status: 'snoozed' as const,
          dateTime: snoozeTime,
          snoozedUntil: snoozeTime,
        }
      : r
  );
  saveReminders(updated);
  return updated;
}

export function completeReminder(id: string): ReminderItem[] {
  const current = getReminders();
  const target = current.find((r) => r.id === id);

  if (!target) return current;

  // If recurring, reschedule to next occurrence and reset status to 'pending'
  if (target.repeatFrequency && target.repeatFrequency !== 'none') {
    const nextDateIso = calculateNextOccurrence(target.dateTime, target.repeatFrequency);
    const updated = current.map((r) =>
      r.id === id
        ? {
            ...r,
            dateTime: nextDateIso,
            status: 'pending' as const,
            snoozedUntil: undefined,
          }
        : r
    );
    saveReminders(updated);
    return updated;
  } else {
    // One-time reminder: set status to 'completed'
    const updated = current.map((r) => (r.id === id ? { ...r, status: 'completed' as const } : r));
    saveReminders(updated);
    return updated;
  }
}

export function toggleReminderStatus(id: string): ReminderItem[] {
  const current = getReminders();
  const target = current.find((r) => r.id === id);
  if (!target) return current;

  if (target.status === 'completed') {
    const updated = current.map((r) => (r.id === id ? { ...r, status: 'pending' as const } : r));
    saveReminders(updated);
    return updated;
  } else {
    return completeReminder(id);
  }
}

export function deleteReminder(id: string): void {
  const current = getReminders();
  const updated = current.filter((r) => r.id !== id);
  saveReminders(updated);
}
