import { Capacitor, registerPlugin } from '@capacitor/core';

interface SilentModePluginInterface {
  isEnabled(): Promise<{ enabled: boolean }>;
  setEnabled(options: { enabled: boolean }): Promise<{ enabled: boolean }>;
  checkRingerMode(): Promise<{ ringerMode: string; isSilent: boolean }>;
}

const SilentModePlugin = registerPlugin<SilentModePluginInterface>('SilentModePlugin');

export const isNativeSilentModeAvailable = (): boolean => {
  return Capacitor.isNativePlatform();
};

export const getSilentReminderEnabled = async (): Promise<boolean> => {
  if (isNativeSilentModeAvailable()) {
    try {
      const res = await SilentModePlugin.isEnabled();
      return res.enabled;
    } catch {
      // fallback to localStorage
    }
  }
  const stored = localStorage.getItem('hafizam_silent_reminder_enabled');
  return stored !== 'false'; // default true
};

export const setSilentReminderEnabled = async (enabled: boolean): Promise<void> => {
  localStorage.setItem('hafizam_silent_reminder_enabled', enabled ? 'true' : 'false');
  if (isNativeSilentModeAvailable()) {
    try {
      await SilentModePlugin.setEnabled({ enabled });
    } catch (e) {
      console.warn('SilentModePlugin setEnabled error:', e);
    }
  }
};

export const checkCurrentRingerMode = async (): Promise<{ ringerMode: string; isSilent: boolean }> => {
  if (isNativeSilentModeAvailable()) {
    try {
      return await SilentModePlugin.checkRingerMode();
    } catch {
      return { ringerMode: 'UNKNOWN', isSilent: false };
    }
  }
  return { ringerMode: 'WEB_PREVIEW', isSilent: false };
};
