import { MemoryItem, ReminderItem, ProcessAIRequest, ProcessAIResponse } from '../types';

export async function processAIQuery(
  request: ProcessAIRequest
): Promise<ProcessAIResponse> {
  try {
    const payload = {
      ...request,
      currentDateTimeIso: request.currentDateTimeIso || new Date().toISOString(),
    };

    const response = await fetch('/api/ai/process', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Sunucu hatası: ${response.status}`);
    }

    const data: ProcessAIResponse = await response.json();
    return data;
  } catch (error: any) {
    console.error('aiService error:', error);
    return {
      intent: 'answer',
      responseText: `Hata oluştu: ${error.message || 'Sunucuya bağlanılamadı.'}`,
      speechText: 'Bağlantı hatası oluştu.',
    };
  }
}

// Text-to-Speech in Natural Female Turkish
export function findTurkishVoice(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return null;

  const trVoices = voices.filter((v) => {
    const lang = (v.lang || '').toLowerCase().replace('_', '-');
    const name = (v.name || '').toLowerCase();

    const isTrLang = lang === 'tr' || lang.startsWith('tr-');
    const isTrName = name.includes('turkish') || name.includes('türkçe') || name.includes('turkce');

    return isTrLang || isTrName;
  });

  if (trVoices.length === 0) return null;

  // Priority order for Turkish voices
  const googleVoice = trVoices.find((v) => v.name.toLowerCase().includes('google'));
  if (googleVoice) return googleVoice;

  const namedVoice = trVoices.find((v) => {
    const name = v.name.toLowerCase();
    return (
      name.includes('yelda') ||
      name.includes('seda') ||
      name.includes('dilara') ||
      name.includes('female') ||
      name.includes('kadın') ||
      name.includes('hazel') ||
      name.includes('natural')
    );
  });
  if (namedVoice) return namedVoice;

  const exactTrTr = trVoices.find((v) => (v.lang || '').toLowerCase().replace('_', '-') === 'tr-tr');
  if (exactTrTr) return exactTrTr;

  return trVoices[0];
}

let currentActiveAudio: HTMLAudioElement | null = null;

export function stopSpeaking(): void {
  if (currentActiveAudio) {
    try {
      currentActiveAudio.pause();
      currentActiveAudio.currentTime = 0;
    } catch (e) {
      // ignore pause error
    }
    currentActiveAudio = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {
      // ignore cancel error
    }
  }
}

function speakTextFallback(text: string, onEnd?: () => void): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onEnd) onEnd();
    return false;
  }

  try {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
    window.speechSynthesis.cancel();

    const doSpeak = (voice: SpeechSynthesisVoice | null) => {
      try {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        if (voice) {
          utterance.voice = voice;
          utterance.lang = voice.lang || 'tr-TR';
        } else {
          utterance.lang = 'tr-TR';
        }

        utterance.rate = 0.98;
        utterance.pitch = 1.05;
        utterance.volume = 1.0;

        utterance.onend = () => {
          if (onEnd) onEnd();
        };

        utterance.onerror = (e) => {
          console.error('[TTS Fallback Error]:', e);
          if (onEnd) onEnd();
        };

        setTimeout(() => {
          window.speechSynthesis.speak(utterance);
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }
        }, 10);
      } catch (err) {
        console.error('[TTS Fallback Execution Error]:', err);
        if (onEnd) onEnd();
      }
    };

    const immediateVoice = findTurkishVoice();
    if (immediateVoice) {
      doSpeak(immediateVoice);
      return true;
    }

    let hasExecuted = false;
    const triggerSpeak = () => {
      if (hasExecuted) return;
      hasExecuted = true;
      if ('onvoiceschanged' in window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = null;
      }
      const foundVoice = findTurkishVoice();
      doSpeak(foundVoice);
    };

    if ('onvoiceschanged' in window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = triggerSpeak;
    }

    setTimeout(() => {
      if (!hasExecuted && findTurkishVoice()) triggerSpeak();
    }, 150);

    setTimeout(() => {
      if (!hasExecuted) triggerSpeak();
    }, 400);

    return true;
  } catch (e) {
    console.error('[TTS Fallback Error]:', e);
    if (onEnd) onEnd();
    return false;
  }
}

export function speakText(text: string, onEnd?: () => void): boolean {
  stopSpeaking();

  if (!text || !text.trim()) {
    if (onEnd) onEnd();
    return false;
  }

  // Primary: Turkish Audio Stream via /api/tts/tr (Free, high-quality, works on Android WebView)
  fetch('/api/tts/tr', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  })
    .then(async (res) => {
      if (!res.ok) {
        throw new Error(`TTS server endpoint returned status ${res.status}`);
      }
      const blob = await res.blob();
      if (!blob || blob.size === 0) {
        throw new Error('Received empty audio blob from TTS endpoint');
      }

      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      currentActiveAudio = audio;

      let isFinished = false;
      const finish = () => {
        if (isFinished) return;
        isFinished = true;
        if (currentActiveAudio === audio) {
          currentActiveAudio = null;
        }
        URL.revokeObjectURL(audioUrl);
        if (onEnd) onEnd();
      };

      audio.onended = finish;
      audio.onerror = (err) => {
        console.warn('[TTS Audio Playback Error]:', err);
        finish();
      };

      audio.play().catch((playErr) => {
        console.warn('[TTS audio.play() failed]:', playErr);
        finish();
      });
    })
    .catch((err) => {
      console.warn('[TTS Server endpoint failed, switching to Web Speech fallback]:', err);
      speakTextFallback(text, onEnd);
    });

  return true;
}
