import { ReminderItem } from '../types';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

function getNumericId(stringId: string): number {
  let hash = 0;
  for (let i = 0; i < stringId.length; i++) {
    hash = (hash << 5) - hash + stringId.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 2147483647 || 1;
}

export function getNotificationPermissionStatus(): NotificationPermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as NotificationPermissionState;
}

export async function requestNotificationPermission(): Promise<NotificationPermissionState> {
  if (typeof window !== 'undefined' && Capacitor.isNativePlatform()) {
    try {
      const result = await LocalNotifications.requestPermissions();
      if (result.display === 'granted') {
        return 'granted';
      }
      return 'denied';
    } catch (e) {
      console.warn('Native requestPermissions error:', e);
    }
  }

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission as NotificationPermissionState;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return getNotificationPermissionStatus();
  }
}

// Web Audio API Chime Sound Generator (no external mp3 needed)
export function playNotificationSound(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();

    // Sequence of 3 soft pleasant chime notes (C5, E5, G5)
    const notes = [523.25, 659.25, 783.99];
    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + index * 0.15);

      gain.gain.setValueAtTime(0, ctx.currentTime + index * 0.15);
      gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + index * 0.15 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + index * 0.15 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + index * 0.15);
      osc.stop(ctx.currentTime + index * 0.15 + 0.45);
    });
  } catch (e) {
    console.warn('AudioContext sound error:', e);
  }
}

// Schedule Native System Notification via Capacitor LocalNotifications
export async function scheduleNativeLocalNotification(reminder: ReminderItem): Promise<boolean> {
  try {
    if (typeof window === 'undefined') return false;

    const targetDate = new Date(reminder.dateTime);
    if (isNaN(targetDate.getTime()) || targetDate <= new Date()) {
      return false;
    }

    const numericId = getNumericId(reminder.id);

    if (Capacitor.isNativePlatform()) {
      // Cancel previous notification with same ID if any
      try {
        await LocalNotifications.cancel({ notifications: [{ id: numericId }] });
      } catch (e) {
        // ignore
      }

      // Check / request permission
      const perm = await LocalNotifications.checkPermissions();
      if (perm.display !== 'granted') {
        const req = await LocalNotifications.requestPermissions();
        if (req.display !== 'granted') return false;
      }

      // Create Android Channel
      try {
        await LocalNotifications.createChannel({
          id: 'hafizam_reminders',
          name: 'Hafızam AI Hatırlatıcılar',
          description: 'Hatırlatıcı bildirimleri ve alarmlar',
          importance: 5, // High importance for heads-up notification + sound
          visibility: 1, // Public on lockscreen
          vibration: true,
        });
      } catch (e) {
        // channel silent catch
      }

      // Register Actions
      try {
        await LocalNotifications.registerActionTypes({
          types: [
            {
              id: 'REMINDER_ACTIONS',
              actions: [
                { id: 'complete', title: 'Tamamlandı' },
                { id: 'snooze_30', title: 'Ertele (30 Dk)' },
                { id: 'delete', title: 'Sil' },
              ],
            },
          ],
        });
      } catch (e) {
        // silent catch
      }

      await LocalNotifications.schedule({
        notifications: [
          {
            id: numericId,
            title: '🔔 Hafızam AI',
            body: reminder.title,
            schedule: { at: targetDate },
            channelId: 'hafizam_reminders',
            actionTypeId: 'REMINDER_ACTIONS',
            extra: {
              reminderId: reminder.id,
              title: reminder.title,
            },
          },
        ],
      });
      console.log(`[Native Local Notification] Scheduled for "${reminder.title}" at ${targetDate.toISOString()}`);
      return true;
    }
  } catch (err) {
    console.warn('[Native Notification Schedule Error]:', err);
  }
  return false;
}

// Cancel Native Notification
export async function cancelNativeLocalNotification(reminderId: string): Promise<void> {
  try {
    if (typeof window !== 'undefined' && Capacitor.isNativePlatform()) {
      const numericId = getNumericId(reminderId);
      await LocalNotifications.cancel({ notifications: [{ id: numericId }] });
      console.log(`[Native Local Notification] Canceled for ID: ${reminderId}`);
    }
  } catch (e) {
    console.warn('[Native Notification Cancel Error]:', e);
  }
}

// Setup Native Notification Action Listeners
export function setupNativeNotificationListeners(
  onComplete: (reminderId: string) => void,
  onSnooze: (reminderId: string, minutes: number) => void,
  onDelete: (reminderId: string) => void
): void {
  try {
    if (typeof window !== 'undefined' && Capacitor.isNativePlatform()) {
      LocalNotifications.addListener('localNotificationActionPerformed', (notificationAction) => {
        const actionId = notificationAction.actionId;
        const reminderId = notificationAction.notification.extra?.reminderId;

        if (!reminderId) return;

        if (actionId === 'complete') {
          onComplete(reminderId);
        } else if (actionId === 'snooze_30' || actionId === 'snooze') {
          onSnooze(reminderId, 30);
        } else if (actionId === 'delete') {
          onDelete(reminderId);
        } else if (actionId === 'tap') {
          window.focus();
        }
      });
    }
  } catch (e) {
    console.warn('[Native Notification Listener Setup Error]:', e);
  }
}

// Trigger browser native notification + sound
export function triggerDeviceNotification(title: string, body?: string): boolean {
  playNotificationSound();

  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const notif = new Notification(`🔔 HAFIZAM AI: ${title}`, {
        body: body || 'Hatırlatma saatiniz geldi!',
        icon: '/favicon.ico',
        tag: 'hafizam-reminder-' + Date.now(),
        requireInteraction: true,
      });

      notif.onclick = () => {
        window.focus();
        notif.close();
      };
      return true;
    } catch (e) {
      console.warn('Native notification failed:', e);
    }
  }
  return false;
}

// Format ISO string to readable Turkish time/date
export function formatReminderDisplay(isoString: string): { timeOnly: string; fullText: string; isToday: boolean } {
  try {
    const date = new Date(isoString);
    if (isNaN(date.getTime())) {
      return { timeOnly: '20:00', fullText: isoString, isToday: false };
    }

    const now = new Date();
    const timeOnly = date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

    const isSameDay =
      date.getDate() === now.getDate() &&
      date.getMonth() === now.getMonth() &&
      date.getFullYear() === now.getFullYear();

    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    const isTomorrow =
      date.getDate() === tomorrow.getDate() &&
      date.getMonth() === tomorrow.getMonth() &&
      date.getFullYear() === tomorrow.getFullYear();

    let dayPrefix = '';
    if (isSameDay) {
      dayPrefix = 'Bugün ';
    } else if (isTomorrow) {
      dayPrefix = 'Yarın ';
    } else {
      dayPrefix = date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' }) + ' ';
    }

    return {
      timeOnly,
      fullText: `${dayPrefix}${timeOnly}`,
      isToday: isSameDay,
    };
  } catch (e) {
    return { timeOnly: '20:00', fullText: isoString, isToday: false };
  }
}

// Alarm loop manager
let activeSchedulerInterval: any = null;

// Track triggered reminder timestamps to prevent repeated notification bursts
const notifiedMap = new Map<string, string>();

export function startNotificationScheduler(
  getReminders: () => ReminderItem[],
  onTriggered: (reminder: ReminderItem) => void
): void {
  if (activeSchedulerInterval) {
    clearInterval(activeSchedulerInterval);
  }

  const checkReminders = () => {
    const reminders = getReminders();
    const now = new Date();

    reminders.forEach((r) => {
      if (r.status === 'pending' || r.status === 'snoozed') {
        const remTime = new Date(r.dateTime);
        if (!isNaN(remTime.getTime()) && remTime <= now) {
          const lastTriggeredTime = notifiedMap.get(r.id);
          // Only trigger if not already triggered for this exact dateTime
          if (lastTriggeredTime !== r.dateTime) {
            notifiedMap.set(r.id, r.dateTime);
            triggerDeviceNotification(
              r.title,
              `Hatırlatma Zamanı: ${formatReminderDisplay(r.dateTime).fullText}${
                r.repeatFrequency && r.repeatFrequency !== 'none'
                  ? ` (Tekrarlayan: ${r.repeatFrequency === 'daily' ? 'Her gün' : r.repeatFrequency === 'weekly' ? 'Her hafta' : 'Her ay'})`
                  : ''
              }`
            );
            onTriggered(r);
          }
        }
      }
    });
  };

  // Run initial check and then every 5 seconds
  checkReminders();
  activeSchedulerInterval = setInterval(checkReminders, 5000);
}

export function stopNotificationScheduler(): void {
  if (activeSchedulerInterval) {
    clearInterval(activeSchedulerInterval);
    activeSchedulerInterval = null;
  }
}
