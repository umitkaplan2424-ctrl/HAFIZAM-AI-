export type CategoryType = 'Belge' | 'Ürün' | 'Cihaz' | 'Fatura' | 'Not' | 'Diğer';
export type RepeatFrequency = 'none' | 'daily' | 'weekly' | 'monthly';
export type ReminderStatus = 'pending' | 'notified' | 'completed' | 'snoozed';

export interface MemoryItem {
  id: string;
  title: string;
  content: string;
  category: CategoryType;
  tags: string[];
  imageUrl?: string;
  createdAt: string; // ISO date string
  source: 'voice' | 'text' | 'camera' | 'manual';
}

export interface ReminderItem {
  id: string;
  title: string;
  dateTime: string; // ISO string
  status: ReminderStatus;
  createdAt: string;
  repeatFrequency?: RepeatFrequency;
  snoozedUntil?: string;
  memoryId?: string;
}

export interface ProcessAIRequest {
  prompt?: string;
  imageBase64?: string;
  mimeType?: string;
  currentMemories?: MemoryItem[];
  currentReminders?: ReminderItem[];
  currentDateTimeIso?: string;
}

export interface ProcessAIResponse {
  intent: 'remember' | 'remind' | 'answer' | 'search' | 'ocr';
  responseText: string;
  speechText?: string;
  memoryToSave?: {
    title: string;
    content: string;
    category: CategoryType;
    tags?: string[];
  } | null;
  reminderToSave?: {
    title: string;
    dateTime: string;
    repeatFrequency?: RepeatFrequency;
  } | null;
  matchedMemoryIds?: string[];
}

export type AppView = 'home' | 'voice' | 'text' | 'reminders';
